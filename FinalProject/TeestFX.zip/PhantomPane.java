package finalProject;
import java.util.ArrayList;
import java.util.HashMap;
import javafx.scene.layout.Pane;

/**
 * Pane subclass that "contains"
 * several alternative Panes within
 * itself, each assigned a String
 * name for reference. The currently
 * displayed Pane can be changed to
 * any of these via a method. Only
 * one Pane can be displayed at a time.
 * 
 * @author Kayden Barlow
 */
public class PhantomPane extends Pane {

	private HashMap<String, Pane> panes = new HashMap<String, Pane>();
	private ArrayList<String> names = new ArrayList<String>();
	
	
	/**
	 * Constructor for instances of the
	 * PhantomPane class. The input Pane
	 * will be added to the list of potential
	 * sub-Panes, with the identifying name
	 * "main", and will be displayed by 
	 * default on construction.
	 * 
	 * @param pane Pane to become the "main"
	 * sub-Pane of this PhantomPane.
	 */
	PhantomPane(Pane pane) {
		//Why are we still here?
		super();
		addPane(pane, "main");
		this.getChildren().add(pane);
	}
	
	
	/**
	 * Constructor for instances of the 
	 * PhantomPane class. By default,
	 * no sub-Panes will have been 
	 * added, and the new PhantomPane
	 * will display nothing. 
	 */
	PhantomPane() {
		//Just to suffer?
		super();
	}
	
	
	/**
	 * Adds the input Pane to the list
	 * of potential sub-Panes, with the 
	 * identifying name determined by
	 * the input String. If the user
	 * does not wish to ever invoke the
	 * getter method for this Pane via its
	 * name, the name will still be required
	 * but can be made arbitrarily.
	 * 
	 * @param pane Pane to be added to the
	 * list of sub-Panes of this object.
	 * @param name String indentifying name of 
	 * the input Pane.
	 */
	public void addPane(Pane pane, String name) {
		//Every night I can feel my legs...
		if (panes.isEmpty()) {
			
			panes.put("main", pane);
			
		} else {
			
			panes.put(name, pane);
		}
	}
	
	
	public boolean removePane(String name) {
		
		return (!(panes.remove(name) == null));
	}
	
	/**
	 * Retrieves a Pane from the list
	 * of sub-Panes via its identifying
	 * name. Throws an exception if no 
	 * Pane with that name is found.
	 * 
	 * @param name String identifying
	 * name of the desired sub-Pane.
	 * @return Pane identified by the
	 * input String.
	 */
	public Pane getPane(String name) {
		//My arms...
		Pane result = panes.get(name);
		
		if (result == null) {

			throw new NullPointerException("Object not found!");
		} else {
			
			return result;
		}
	}
	

	
	
	/**
	 * Retrieves the sub-Pane currently
	 * set to be displayed.
	 * 
	 * @return Pane currently displayed
	 * by this PhantomPane.
	 */
	public Pane getCurrent() {
		
		return (Pane)(this.getChildren().get(0));
	}
	
	
	/**
	 * Clears the currently displayed 
	 * sub-Pane and displays one 
	 * identified by the input String
	 * name. 
	 * 
	 * @param name String name identifying
	 * the new sup-Pane to be displayed.
	 */
	public void changePane(String name) {
		
		this.getChildren().clear();
		
		this.getChildren().add(getPane(name));
	}
	
	

	
	/**
	 * Clears the currently displayed 
	 * sub-Pane and displays the first
	 * sub-Pane added to the list.
	 */
	public void mainPane() {
	
		this.getChildren().clear();
		
		this.getChildren().add(getPane("main"));
	}
}
