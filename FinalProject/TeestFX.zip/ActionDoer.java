package finalProject;

/**
 * One-method interface designed to allow for
 * lambdas facilitating Action effects.
 * 
 * @author Kayden Barlow
 */
public interface ActionDoer {

	/**
	 * Intended for the facilitation of 
	 * Action effects on a target Entity.
	 * Since generics hate me, some casting
	 * may be necessary for some non-consolidated
	 * Action subclass methods.
	 * 
	 * @param action Action whose parameters are to
	 * be invoked.
	 * @param target Entity affected by the Action.
	 * @return String of the results of the effect.
	 */
	public String doinguAcushun(Action action, Entity target);
}