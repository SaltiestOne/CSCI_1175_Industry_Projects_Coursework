package finalProject;

public class NewStatButton extends FormattedButton implements PaintableButton{

	private Stat stat;
	private Fighter user;
	
	/**
	 * Constructor for instances of the 
	 * NewStatButton class. Invokes the
	 * paint method in the constructor for
	 * convenience. By default, the Button 
	 * is assigned an EventHandler
	 * that either increments the associated
	 * Stat's level or throws an exception if
	 * it is at max. This EventHandler can
	 * be overriden as normal.
	 * 
	 * @param stat Stat object to be assigned
	 * to this Button.
	 * @param 
	 */
	NewStatButton(Stat stat, Fighter user) {
		
		super();
		this.stat = stat;
		this.user = user;
		paint();
		this.setOnAction(e -> {
			
			if (user.addStat(stat)) {
				
			} else {
				throw new IllegalArgumentException(user.getName() + " has their maximum number of stats.");}});
	}
	
	
	/**
	 * Returns the Stat object associated
	 * with this NewStatButton.
	 * 
	 * @return Stat associated with this
	 * button.
	 */
	public Stat getStat() {
		
		return this.stat;
	}
	
	
	/**
	 * As required by the PaintableButton
	 * interface, "paints" the text of the 
	 * Button. Text will always be set to
	 * the name of the assigned Stat.
	 */
	public void paint() {
		
		this.setText("Add " + stat.getName());
	}
}