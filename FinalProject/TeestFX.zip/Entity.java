package finalProject;

/**
 * Describes an interactable object.
 * Currently, is pretty redundant with
 * Fighter, but allows for other subclasses
 * to be defined. 
 * 
 * @author Kayden Barlow
 */
interface Entity {

	/**
	 * Returns the String of the
	 * Entity's name.
	 * 
	 * @return String name of the Entity.
	 */
	public String getName();
	
	/**
	 * Returns a name appropriate for referring
	 * to the Entity in a proper sentence.
	 * 
	 * @return String of a contextual variant of 
	 * the Entity's name.
	 */
	public String getPerspectiveName();
	
	/**
	 * Formats the input message according
	 * to whatever parameters the subclass
	 * finds necessary. Should be invoked
	 * by most String-outputing methods.
	 * 
	 * @param message String to formatted.
	 * @return String formatted by the Entity
	 * to be output as a readable sentence.
	 */
	public String formatMessage(String message);
	
	/**
	 * Returns an integer value of the Entity's 
	 * relative power.
	 *  
	 * @return Integer "level."
	 */
	public int getLevel();
	
	
	/**
	 * Returns the integer value of the
	 * Entity's maximum health parameter.
	 * 
	 * @return Integer value of the 
	 * Entity's maximum health.
	 */
	public int getMaxHealth();
	
	/**
	 * Adjusts the Entity's maximum
	 * health parameter to the input amount.
	 * Maximum health should not be negative.
	 * If the boolean input is set to "True"
	 * then health should be set equal to the 
	 * value of maximum health.
	 * 
	 * @param maxHealth Integer value of the
	 * new maximum health.
	 * @param heal If True, health parameter
	 * is made equal to maximum.
	 */
	public void setMaxHealth(int maxHealth, boolean heal);
	
	/**
	 * Returns the integer value of the
	 * Entity's current health parameter.
	 * 
	 * @return Integer value of the Entity's
	 * health.
	 */
	public int getHealth();
	
	/**
	 * Adjusts the Entity's health parameter
	 * to the input integer. Health should not
	 * be negative or exceed the Entity's 
	 * maximum health parameter.
	 * 
	 * @param health Integer value of the
	 * Entity's new health parameter.
	 */
	public void setHealth(int health);
	
	/**
	 * Assigns a Stat object to this Entity
	 * in some way.
	 * 
	 * @param stat Stat to be assigned to
	 * this Entity.
	 * @return True if Stat was added, False
	 * if it was not.
	 */
	public boolean addStat(Stat stat);
	
	
	/**
	 * Retreives the full PronounsSet
	 * object that this Entity is using.
	 * 
	 * @return PronounSet used by this
	 * Entity.
	 */
	public PronounSet getPronouns();
	
	
	/**
	 * Returns a String displaying 
	 * max and current health.
	 * 
	 * @return A String with the current and max health,
	 * seperated by a slash.
	 */
	public String healthGauge();
	
	
	/**
	 * Indicates if this Entity has 
	 * been damaged, usually defined
	 * as having a current health
	 * parameter below its maximum.
	 * 
	 * @return False if the health parameter
	 * is at its maximum, True otherwise.
	 */
	public boolean isDamaged();
	
	/**
	 * Indicates if this Entity has
	 * been defeated, usually defined
	 * as its health parameter being
	 * nonpositive.
	 * 
	 * @return
	 */
	public boolean isDead();
	//that sounds like a hilarious euphamism out of context lol
	
	
	/**
	 * Reduce the Entity's health
	 * by the input amount. Should
	 * not be able to reduce below
	 * zero in most cases.
	 * 
	 * @param damage Integer amount
	 * to decrement the health parameter.
	 * @return Integer identical to 
	 * input.
	 */
	public int harm(int damage);
	
	
	/**
	 * Increase the Entity's health
	 * by the input amount. Should 
	 * not be able to exceed the maximum
	 * health in most cases.
	 *  
	 * @param cure Integer amount to
	 * increment the health parameter.
	 * @return Integer identical to input.
	 */
	public int heal(int cure);
	
	
	/**
	 * Returns a single-line String
	 * describing that fact that the
	 * Entity has been damaged. Many
	 * Actions will invoke this to 
	 * create their output text. 
	 * Should not, in and of itself,
	 * damage the Entity. 
	 * 
	 * @param damage Integer damage
	 * inflicted to this Entity.
	 * @return String describing this
	 * Entity receiving damage.
	 */
	public String damageMessage(int damage);
	
	//abstract public String disable(int potency);
	
	/**
	 * Causes the Entity to
	 * have a parameter of some
	 * kind reduced by the integer
	 * input value.
	 * 
	 * @param potency Integer penalty
	 * to one of the Entity's parameters
	 * or outputs.
	 * @return True if reduction was 
	 * carried out.
	 */
	abstract public boolean weaken(int potency);
	
	/**
	 * Returns a three-to-four line 
	 * descriptor of the Entity, such
	 * as the kind one might find in a menu. 
	 * 
	 * @return String containing end-user
	 * information on this Entity.
	 */
	abstract public String statusMessage();

	/**
	 * Prevents the Entity from acting. 
	 */
	public void stun();
	
}
