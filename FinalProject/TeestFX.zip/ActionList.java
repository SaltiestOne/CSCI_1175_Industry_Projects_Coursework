package finalProject;

/**
 * Class for containing a number
 * of Action objects. 
 * 
 * @author Kayden Barlow
 */
public class ActionList {
	
	private ActionUser user;
	private Action[] list = new Action[(Stat.getMaxLevel() * 3) + 1];
	private int total = 0;
	
	
	/**
	 * Constructor for new ActionLists.
	 * By default, the list has a maximum
	 * capacity of three times the max 
	 * level of a Stat object, plus one.
	 * 
	 * @param user ActionUser associated
	 * with all Actions on the list.
	 */
	ActionList(ActionUser user) {
		
		this.user = user;
	}
	
	/**
	 * Returns the number of actions
	 * assigned to the ActionList.
	 * 
	 * @return Integer number of Actions
	 * on the list.
	 */
	public int size() {
		
		return total;
	}
	
	
	/**
	 * Adds a new Action to the list,
	 * if there is capacity. Returns 
	 * a Boolean indicating if the 
	 * Action was added.
	 * 
	 * @param action Action to be added to
	 * the list.
	 * @return True if Action was added,
	 * False otherwise.
	 */
	public boolean add(Action action) {
		
		if (total < list.length) {
			
			list[total++] = action;
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Adds an Action to the list at 
	 * the desired index. If the index is
	 * greater than the maximum number of 
	 * allowed Actions, no Action is added
	 * and False is returned. If the index 
	 * is above the total number of Actions
	 * already added, the index parameter
	 * is ignored and the Action is added to
	 * first available spot.
	 * 
	 * @param action Action to be added to
	 * the list.
	 * @param index Integer index of location
	 * to add the Action.
	 * @return True if Action was added,
	 * False otherwise.
	 */
	public boolean add(Action action, int index) {
		
		if ((index - 1) > list.length) {
		
			return false;
			
		} else if ((index - 1) > total) {
			
			return add(action);

		} else {
			
			list[index] = action;
			
			return true;
		}
	}
	
	
	/**
	 * Returns the reference of an
	 * Action based on its String name.
	 * If no Action is found, throws
	 * an exception. 
	 * 
	 * @param name String name of 
	 * desired Action.
	 * @return Action with input name
	 * from this list.
	 */
	public Action get(String name) {
		
		for (int a = 0; a < total; a++) {
			
			if (list[a].getName().equals(name)) {
				
				return list[a];
			} else {}
		}
		
		throw new IllegalArgumentException("\"" + name + "\" not found.");
	}
	
	
	/**
	 * Returns an Action from this 
	 * list equivalent to its reference.
	 *  
	 * @param action Action on this
	 * list.
	 * @return 
	 *
	public Action get(Action action) {
		
		return get(action.getName());
	}*/
	
	
	/**
	 * Determines if any Actions on this
	 * list are of the subclass indicated
	 * by a "typeName" String (defined by
	 * Action subclasses themselves.
	 * 
	 * @param typeName String name of the
	 * desired Action subclass.
	 * @return True if at least one Action
	 * of desired subclass was found, False
	 * otherwise.
	 */
	public boolean hasActionType(String typeName) {
		
		for (int a = 0; a < total; a++) {
			
			if (list[a].getTypeName().equals(typeName)) {
				
				return true;
			} else {}
		}
		
		return false;
	}
	
	
	/**
	 * Returns an array containing
	 * all Actions on this list which
	 * are of a certain Action subclass,
	 * as determined by the "typeName"
	 * String defined by these subclasses
	 * themselves.
	 * 
	 * @param typeName String name of a
	 * Action subclass.
	 * @return Action array containing
	 * all Actions on this list which ar
	 * instances of a particular subclass.
	 */
	public Action[] getActionType(String typeName) {
		
		Action[] getter = new Action[total];
		
		int count = 0;
		
		for (int a = 0; a < total; a++) {
			
			if (list[a].getTypeName().equals(typeName)) {
				
				getter[count++] = list[a];
			} else {}
		}
		
		if (count == 0) {
			
			throw new IllegalArgumentException("No \"" + typeName + "\" Actions found.");
		} else {
			
			Action[] result = new Action[count];
			
			for (int a = 0; a < count; a++) {
				
				result[a] = getter[a];
				
			}
		
			return result;
		}
	}
	
	/**
	 * Returns an Action array containing
	 * all Actions on this list that 
	 * are associated with the input Stat
	 * object. Note that this direct association;
	 * returned Actions are the ones with
	 * the input Stat in their parameters,
	 * not merely ones that scale from them
	 * or could be built from them. Array 
	 * length is equal to the number of items.
	 * 
	 * @param stat Stat associated with desired
	 * Actions.
	 * @return Action array containing all 
	 * relevant Actions.
	 */
	public Action[] getFromStat(Stat stat) {
		
		Action[] getter = new Action[Stat.getMaxLevel()];
		
		int count = 0;
		
		for (int a = 0; a < total; a++) {
			
			if (list[a].getStat().equals(stat)) {
				
				getter[count++] = list[a];
			}
		}
		
		if (count == 0) {
			
			throw new IllegalArgumentException("No Actions scaling from \"" + stat.getName() + "\".");
		} else {
			
			Action[] result = new Action[count];
			
			for (int a = 0; a < count; a++) {
				
				result[a] = getter[a];
			}
		
			return result;
		}
		
	}
	
	/**
	 * Searches this list for an unlearned 
	 * Action associated with the input 
	 * Stat object. The first time that one
	 * is found, the Action is marked learned
	 * and returned. Throws an exception if 
	 * no unlearned Actions associated with 
	 * the input Stat are found.
	 * 
	 * @param stat Stat associated with
	 * target Action.
	 * @return Action found and marked
	 * learned by this method.
	 */
	public Action learnFromStat(Stat stat) {
		
		for (int a = 0; a < total; a++) {
			
			if ((list[a].getStat().equals(stat)) 
					&& (!(list[a].isLearned()))) {
				
				list[a].learn();
				
				return list[a];
			} else {}
		}
		
		throw new IllegalArgumentException("No unlearned Actions scaling from " + stat.getName() + ".");
	}
	
}
