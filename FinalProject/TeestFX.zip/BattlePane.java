package finalProject;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;

/**
 * Pane subclass displaying the names
 * and health Gauges of two Fighter
 * objects in boxes. This object does
 * not make use of any listeners or 
 * passive observables, and thus must
 * be re-painted via the included void
 * method to reflect changes in the 
 * Fighter's paramters. Requires the 
 * Formatter class for Font, size, and
 * Color formatting.
 * 
 * @author Kayden Barlow
 */
public class BattlePane extends Pane {

	private Fighter leftFighter;
	private Fighter rightFighter;
	private Text leftName;
	private Text leftGauge;
	private Text rightName;
	private Text rightGauge;
	
	
	
	/**
	 * Constructor for instances of the 
	 * BattlePane class. Input Fighter 
	 * objects will have thier names and
	 * health Gauges displayed in boxes.
	 * As these are the only Fighter
	 * parameters called for or used in
	 * any method of this object, any 
	 * Fighter subclass should suffice. 
	 * 
	 * @param rightFighter Fighter object to
	 * be displayed in the right box.
	 * @param leftFighter Fighter object to
	 * be displayed in the left box.
	 */
	BattlePane(Fighter rightFighter, Fighter leftFighter) {
		
		super();
		this.rightFighter = rightFighter;
		this.leftFighter = leftFighter;
		
		this.rightName = new Text(rightFighter.getName());
		this.rightGauge = new Text(rightFighter.healthGauge());
		rightGauge.xProperty().bind(rightName.xProperty());
		
		this.leftName = new Text(leftFighter.getName());
		this.leftGauge = new Text(leftFighter.healthGauge());
		
		rightName.yProperty().bind(leftName.yProperty());
		rightGauge.yProperty().bind(leftGauge.yProperty());
		
		this.setBackground(null);
		
		paint();
		
	}
	
	
	/**
	 * Sets all of the Nodes in the 
	 * object, including drawing 
	 * the boxes and positioning
	 * the parameter displays.
	 */
	private void paint() {
		
		rightName.fontProperty().bind(leftName.fontProperty());
		leftName.setFont(Formatter.getBoldFont(24));
	
		rightGauge.fontProperty().bind(leftGauge.fontProperty());
		leftGauge.setFont(Formatter.getItalicFont(22));
		
		
		int top = 145;
		int mid = 225;
		int spacer = 21;
		int stroke = 4;
		
		
		//below is black box for assumed formatting
		int width = (mid * 2);
		Line ceiling = new Line(0,top, width,top);
		ceiling.setStrokeWidth(stroke);
		ceiling.setStrokeLineCap(StrokeLineCap.ROUND);
		ceiling.setStroke(Formatter.getMainColor());
		
		leftName.setX((mid - spacer) - (leftName.getLayoutBounds().getWidth()));
		leftName.setY(top + (leftName.getLayoutBounds().getHeight()) + spacer);
		
		leftGauge.setX((mid - spacer) - (leftGauge.getLayoutBounds().getWidth()));
		leftGauge.setY(leftName.getY() + (leftName.getLayoutBounds().getHeight()) + spacer);
		
		rightName.setX(mid + spacer);
		
		int bottom = (int)(leftGauge.getY()) + spacer;
		
		Line pillar = new Line(mid,top, mid,bottom);
		pillar.setStrokeWidth(stroke);
		pillar.setStroke(Formatter.getMainColor());
		
		Line floor = new Line(0,bottom, width, bottom);
		floor.setStrokeWidth(stroke);
		floor.setStroke(Formatter.getMainColor());
		
		
		this.getChildren().clear();
		this.getChildren().addAll(ceiling, leftName, leftGauge, pillar, rightName, rightGauge, floor);
		
		update();
	}
	
	
	/**
	 * Adds a new Fighter to the box
	 * on the left. Automatically
	 * paints the Pane to reflect
	 * changes in the positioning of
	 * the Fighter's parameters as a 
	 * result of differing text lengths.
	 * 
	 * @param leftFighter Fighter object
	 * to be displayed in the left box.
	 */
	public void setLeftFighter(Fighter leftFighter) {
		
		this.leftFighter = leftFighter;
		this.leftName.setText(leftFighter.getName());
		paint();
	}
	
	
	/**
	 * Adds a new Fighter to the box
	 * on the right. Automatically
	 * paints the Pane to reflect
	 * changes in the positioning of
	 * the Fighter's parameters as a 
	 * result of differing text lengths.
	 * 
	 * @param leftFighter Fighter object
	 * to be displayed in the right box.
	 */
	public void setRightFighter(Fighter rightFighter) {
		
		this.rightFighter = rightFighter;
		this.rightName.setText(rightFighter.getName());
		paint();
	}
	
	
	/**
	 * Adjusts the text and formatting
	 * of the associated Fighter's 
	 * displayed parameters. Can (and
	 * must) be invoked whenever this
	 * information has changed. 
	 */
	public void update() {
		
		rightGauge.setText(rightFighter.healthGauge());
		rightName.setFill(Formatter.getMainColor());

		if (rightFighter.isDead() ) {
			
			rightName.setFill(Formatter.getFadeColor());
			rightGauge.setFill(Formatter.getFadeColor());
		} else if (rightFighter.isDamaged()) {
			
			rightGauge.setFill(Formatter.getWarnColor());
		} else {
			
			rightGauge.setFill(Formatter.getMainColor());
		}
		
		leftGauge.setText(leftFighter.healthGauge());
		leftGauge.setX((204) - (leftGauge.getLayoutBounds().getWidth()));
		leftName.setFill(Formatter.getMainColor());
		
		if (leftFighter.isDead() ) {
			
			leftName.setFill(Formatter.getFadeColor());
			leftGauge.setFill(Formatter.getFadeColor());
		} else if (leftFighter.isDamaged()) {
			
			leftGauge.setFill(Formatter.getWarnColor());
		} else {
			
			leftGauge.setFill(Formatter.getMainColor());
		}
	}	
}
