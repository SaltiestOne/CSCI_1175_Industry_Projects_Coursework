package finalProject;

import java.util.HashMap;
import java.util.Random;

/**
 * Abstract class containing a map of all
 * ActionDoers currently in the game,
 * which can be retreived via a String
 * "name" key.
 * 
 * @author Kayden Barlow
 */
public abstract class AllActions {

	static private HashMap<String, ActionDoer> allActions = new HashMap<String, ActionDoer>();
	static private boolean set = false;
	
	/**
	 * Returns an ActionDoer lambda based on an
	 * input name. Throws an exception if no
	 * name is found in the internal map. 
	 * 
	 * @param name String name of desired ActionDoer.
	 * @return ActionDoer lambda linked with input name.
	 */
	public static ActionDoer getDoer(String name) {
		
		set();
		
		ActionDoer result = allActions.get(name);
		
		if (result == null) {
			
			throw new IllegalArgumentException("ActionDoer \"" + name + "\" not found.");
		} else {
			
			return result;
		}
	}
	
	
	/**
	 * Sets up the static map of all
	 * currently implemented ActionDoers.
	 * Tracks a static boolean to prevent 
	 * redundant calls. 
	 */
	private static void set() {
		
		if (!set) {
			
			//The "Lunge" Weapon Skill.
			allActions.put("Lunge", ((a, t) -> {

				String output = ("[u] lunge[s] at [t] with [pp] [i].\n" +
				t.damageMessage(a.quickUse(t)));
						
				if ((t instanceof Monster) && t.isDead()) {
				//if target is dead, they cannot mutual-kill
					t.stun();
					
					((Monster)t).setSpecial(false);
				} else {}
				
				return output;}));
			
			
			//The "Mana Burst" weapon Skill.
			allActions.put("Mana Burst", ((a, t) -> {
					
				String output;
				
				int manaCost = ((int)(((Caster)a.getUser()).getMaxMana() * .5));
				
				if (((Caster)a.getUser()).getMana() >= manaCost) {
					
					output = ("[u] channel[s] Mana into [pp] [i].\n" +
					t.damageMessage(a.quickUse(a.scale(), t)));
	
					((Caster)a.getUser()).adjustMana(-manaCost);
					
				} else if ((a.getUser().getAction("Ascend")).isLearned()) {
				
					output = ("[u] sacrifice[s] " + a.getUser().harm(Scaler.damage(a.getStat())) +
					 " health to abstract [pp] " + a.getImplement() + ",\nStriking " + t.getPerspectiveName() + 
					 "for " + a.quickUse(t) + " damage!\n");
				} else {
					
					throw new IllegalArgumentException("No Mana to Burst.");
				}
				
				return output;}));
				
				allActions.put("Counter", ((a, t) -> {
				
					int damage = a.quickUse(t);
					//has relatively weak scaling
				
					t.weaken(damage);
				
					return ("[u] attack[s] while braceing [pp] [i].\n" +
					t.damageMessage(damage));}));
				
				allActions.put("Mana Burst(Sp)", ((a, t) -> {
					//Mana Burst but as a spell since I can't be bothered to change the original
					return ("[u] channel[s] Mana into [pp] [i].\n" +
							t.damageMessage(a.quickUse(t)));
				}));
				
				
				//The "Shield Bash" shield Skill
				allActions.put("Shield Bash", ((a, t) -> {
					
					String output = "[u] slam[s] [pp] [i] into [t].\n" + 
							t.damageMessage(a.quickUse(t));
					
					if ((new Random().nextBoolean())) {
						
						t.stun();
						
						a.cost();
					} else {}
					
					return output;}));
			
				allActions.put("Drain", ((a, t) -> {
					
					int damage = a.scale();
					a.cost();
					t.weaken(damage);

					return ("[u] drain[s] Mana from [t],\n restoring "+
							a.getUser().heal(damage) + " of [pp] health!\n");}));
				
				allActions.put("Bolt", ((a, t) -> {
			
					return "[u] send[s] a flare of energy towards [t].\n" +
							t.damageMessage(a.quickUse(t));}));
				
				allActions.put("Ascend", ((a, t) -> {

					int upMana = (int)(((Caster)a.getUser()).getMaxMana() * .5);
					
					((Caster)a.getUser()).setMana(((Caster)a.getUser()).getMana() + upMana);
						//"trust no one, not even yourself"
					
					return ("[u] abstract[s] [pp] own lifeforce,\n exchanging " +
						a.getUser().harm(a.scale()) + " health for " +
						upMana + " Mana.\n");}));
				
				allActions.put("Revert", ((a, t) -> {
					
					a.cost();
					
					return ("[u] channel[s] Mana into [pf],\nrestoring " + 
							a.getUser().heal(a.scale()) + " health.\n");}));
				
				allActions.put("Astra", ((a, t) -> {
					
					int stars = (new Random().nextInt(((Caster)a.getUser()).getMana() / (a.getCost())) + 1);
				
					if (stars <= 0) {
					
						return ("The Stars cross against [u]...\nNo damage dealt.\n");
						//spell has a chance to fail.
					} else {
					
						int damage = 0;
						String output = "";
						
						for (int s = 0; s < stars; s++) {
							
							damage += (a.scale());
						
							a.cost();
						}
						
						if (stars == 1) {
							
							output = "A Star crosses ";
						} else {
							/*thank goodness this isnt a commercial project that required
							localization or else I'd probably need to make (or find)
							an object to dynamically handle plural conjugation lol*/
							output = (stars + " Stars cross ");
						}
	
						return (output + "against [t].\n " +
								t.damageMessage(t.harm(damage)));}}));
				
				allActions.put("Metabolic Aid", ((a, t) -> {
					
					int count = 0;
					int heal = (a.getUser().getHealth() - 1);
					while (a.cost() && a.getUser().isDamaged()) {
						
						a.getUser().heal(heal);
						count++;
					}
					
					String output;
					
					if (a.getUser().isDamaged()) {
						
						output = ("[u] restore[s] [pf] to " +
						a.getUser().getHealth() + "health,\n using ");
						
						
					} else {
						
						output = ("[u] fully restore[s] [pp] health,\n using ");
					}

					if  (count == 1) {
							
						if (((Item)a).getStock() == 0) {
							output += "[pp] very last [i].\n";
						} else {
							
							output += "a single [i].\n";
						}
					} else {
						
						output += (count + " [i]s.\n");
					}
					
					return output;
				}));
				
				allActions.put("Eviscerate", ((a, t) -> {
					
					if (new Random().nextBoolean()) {
						
						a.cost();
						
						return ("[u] launch[es] a reckless assualt with [pp] [i]!\n " + 
						t.damageMessage(t.harm(a.scale() * 3)));
					} else {
						
						a.cost();
						
						return ("[u] attempt[s] to launch a reckless assualt,\n but [ps] just leave[s] [pf] open..."); 
					}}));
				
				
				
				
				
				
				//allActions.put("Black Arrow", ((a, t) -> {}));
			
			set = true;
			
		} else {}
	}
}
