package finalProject;
/**
 * FormattedButton subclass that facilitates 
 * leveling up a particular Stat object. 
 * Implements PaintableButton to update the
 * information written on the Button to reflect
 * any changes to the Stat. As a FormattedButton
 * subclass, requires the Formatter class.
 * 
 * @author Kayden Barlow
 */
public class UpgradeButton extends FormattedButton implements PaintableButton {

	private Stat stat;
	
	
	/**
	 * Constructor for instances of the 
	 * UpgradeButton class. Invokes the
	 * paint method in the constructor for
	 * convenience. By default, the Button 
	 * is assigned an EventHandler
	 * that either increments the associated
	 * Stat's level or throws an exception if
	 * it is at max. This EventHandler can
	 * be overriden as normal.
	 * 
	 * @param stat Stat object to be assigned
	 * to this Button.
	 */
	UpgradeButton(Stat stat) {
		
		super();
		this.stat = stat;
		paint();
		this.setOnAction(e -> {
			
			if (this.stat.isAtMax()) {
				
				throw new IllegalArgumentException((this.stat.getName()) + "is already at max level!");
			} else {
				this.stat.upLevel();}});
	}
	
	
	/**
	 * Returns the Stat object associated
	 * with this UpgradeButton.
	 * 
	 * @return Stat associated with this
	 * button.
	 */
	public Stat getStat() {
		
		return this.stat;
	}
	
	
	/**
	 * As required by the PaintableButton
	 * interface, "paints" the text of the 
	 * Button. Text will always be set to
	 * the Stat's menuMessage String, and 
	 * Color will be the Formatter class's
	 * fade Color if the Stat is at max level,
	 * and the normal Color otherwise. 
	 */
	public void paint() {
		
		this.setText(this.stat.menuMessage(true));
		
		if (this.stat.isAtMax()) {
			
			this.setTextFill(Formatter.getFadeColor());
		} else {}
	}
}
