package finalProject;

/**
 * Object class containing a series of 
 * Strings representing various sets
 * of pronouns in the English language.
 * Currently includes third-person pronouns
 * for male, female, non-gendered, and plural
 * entities, as well as second-person pronouns.
 * 
 * @author Kayden Barlow
 */
public class PronounSet {

	private String subject;
	private String object;
	private String possesive;
	private String self;
	private boolean thirdPersonConj;
	private boolean isSecond;
	
	
	/**
	 * Private internal constructor for
	 * different sets of pronouns.  
	 * 
	 * @param subject String subject pronoun.
	 * @param object String object pronoun.
	 * @param possesive String possesive pronoun.
	 * @param self String reflexive pronoun.
	 * @param thirdPersonConj Boolean representing if 
	 * the PronounSet uses third-person singular
	 * verb conjugation.
	 * @param isSecond Boolean representing if the
	 * PronounSet is the second-person tense.
	 */
	private PronounSet(String subject, String object, String possesive, String self, 
			boolean thirdPersonConj, boolean isSecond) {

		this.subject = subject;
		this.object = object;
		this.possesive = possesive;
		this.self = self;
		this.thirdPersonConj = thirdPersonConj;
		this.isSecond = isSecond;
	}
	
	/**
	 * Returns the subject pronoun
	 * of the Set.
	 * 
	 * @return String subject pronoun.
	 */
	public String subjectPronoun() {
		
		return subject;
	}
	
	
	/**
	 * Returns the object pronoun
	 * of the Set.
	 * 
	 * @return String object pronoun.
	 */
	public String objectPronoun() {
		
		return object;
	}
	
	
	/**
	 * Returns the possesive pronoun
	 * of the Set.
	 * 
	 * @return String possesive pronoun.
	 */
	public String possesivePronoun() {
		
		return possesive;
	}
	
	
	/**
	 * Returns the reflexive pronoun
	 * of the Set.
	 * 
	 * @return String reflexive pronoun.
	 */
	public String selfPronoun() {
		
		return self;
	}
	
	
	/**
	 * Indicates if this PronounSet should
	 * use third-person singular verb conjugation.
	 * 
	 * @return True if the Pronouns is set
	 * are third-person singular, False
	 * otherwise.
	 */
	public boolean usesThirdPersonConj() {
		
		return thirdPersonConj;
	}
	
	/**
	 * Indicates if this PronounSet is 
	 * the second-person pronouns.
	 * 
	 * @return True if these pronouns are
	 * second-person, False otherwise.
	 */
	public boolean isSecondPerson() {
		
		return isSecond;
	}
	
	/**
	 * Formats an input String to replace
	 * certain placeholders with the appropriate
	 * pronouns of this Pronoun Set. [ps] will
	 * become the subject pronoun, [po] the 
	 * object pronoun, [pp] the possessive
	 * pronoun, and [pf] the reflexive pronoun.
	 * Additionally, any [s], [es], and [ies] 
	 * will be kept or removed as necessary for 
	 * third-person singular verb conjugation.
	 * 
	 * @param string String to be formatted.
	 * @return Formatted String.
	 */
	public String formatPronouns(String string) {
		
		return formatPronouns(string, this);
	}
	
	
	
	/**
	 * Formats an input String to replace
	 * certain placeholders with the appropriate
	 * pronouns of the input Pronoun Set. [ps] will
	 * become the subject pronoun, [po] the 
	 * object pronoun, [pp] the possessive
	 * pronoun, and [pf] the reflexive pronoun.
	 * Additionally, [s], [es], and [ies] will be kept
	 * or replaced as necessary for third-person
	 * singular verb conjugation.
	 * 
	 * @param string String to be formatted.
	 * @param pronouns PronounSet to be referrenced
	 * when formatting the String.
	 * @return Formatted String.
	 */
	public static String formatPronouns(String string, PronounSet pronouns) {
		
		string = string.replace("[ps]", pronouns.subjectPronoun());
		string = string.replace("[po]", pronouns.objectPronoun());
		string = string.replace("[pp]", pronouns.possesivePronoun());
		string = string.replace("[pf]", pronouns.selfPronoun());
		
		if (pronouns.usesThirdPersonConj()) {
			
			string = string.replace("[s]", "s");
			string = string.replace("[es]", "es");
			string = string.replace("[ies]", "ies");
		} else {
			
			string = string.replace("[s]", "");
			string = string.replace("[es]", "");
			string = string.replace("[ies]", "y");
		}
		return string;
	}
	
	/** 
	 * Returns the second-person singular 
	 * ("you") pronouns. Typically used for
	 * second-person plural as well, but this
	 * varies by region and tone.
	 * 
	 * @return PronounSet 
	 */
	public static PronounSet secondPersonPronouns() {
		
		return new PronounSet("you", "you", "your", "yourself", false, true);
	}
	
	
	/**
	 * Returns the third-person singualr male 
	 * ("he") pronouns.
	 * 
	 * @return PronounSet for male pronouns.
	 */
	public static PronounSet malePronouns() {
		
		return new PronounSet("he", "him", "his", "himself", true, false);
	}

	
	/**
	 * Returns the third-person singualr female 
	 * ("she") pronouns.
	 * 
	 * @return PronounSet for female pronouns.
	 */
	public static PronounSet femalePronouns() {
		
		return new PronounSet("she", "her", "her", "herself", true, false);
	}
	
	
	/**
	 * Randomly returns the pronouns of 
	 * either gender. Should be invoked only
	 * once when assigned to something with a
	 * fixed gender, as this method will 
	 * invoke its random procedure every time.
	 * 
	 * @return PronounSet for either male or 
	 * female pronouns, determined randomly.
	 */
	public static PronounSet randomGenderPronouns() {
		
		if (new java.util.Random().nextBoolean()) {
			
			return malePronouns();
		} else {
			
			return femalePronouns();
		}
	}

	/**
	 * Returns the gender-neutral third-person 
	 * singular ("it") pronouns. 
	 * 
	 * @return PronounSet for gender-neutral pronouns.
	 */
	public static PronounSet neutralPronouns() {
		
		return new PronounSet("it", "it", "its", "itself", true, false);
	}

	/**
	 * Returns the third-person plural ("they") pronouns. 
	 * As per English convention, can be used as
	 * gender-neutral pronouns as well. 
	 * 
	 * @return PronounSet for plural/neutral pronouns.
	 */
	public static PronounSet pluralPronouns() {
		//lol imagine a language where third-person plurals were gendered
		return new PronounSet("they", "them", "their", "themselves", false, false);
	}
}
