package finalProject;
/**
 * An Action for a basic, no-cost attack.
 * 
 * @author Kayden Barlow
 */
class BasicAttack extends Action {
	
	
	/**
	 * Basic Attack has a set name, never
	 * increases Cooldown, and is always learned.
	 * Invokes the "incidental" Action constructor,
	 * and is thus never added to the allActions list.
	 * 
	 * @param stat Attacking Stat object from which
	 * scaling and other parameters are derived.
	 */
	BasicAttack(Attacking stat) {
		
		super("Attack", 0, (Stat)stat, true, "BasicAttack");
		
		this.addDamageScaler(e -> {
			
			return Scaler.damage((Stat)stat);
		});
		
		this.setActionDoer((a, t) -> {
			
			return (stat.attackMessage() + t.damageMessage(a.quickUse(t)));});
	}

	/**
	 * As a basic attack does not have any
	 * resource or usability conditions, its 
	 * name alone suffices for a selection message.
	 * 
	 * @return String of the BasicAttack's name
	 * (should be "Attack", as per
	 * the constructor).
	 */
	String menuMessage() {
		
		return this.getName();
	}
	
	/**
	 * Returns True regardless of the normal factors
	 * defined in the Skill superclass. A basic attack
	 * should always be learned and usable regardless
	 * of current Cooldown.
	 * 
	 * @return True, always.
	 */
	boolean isUsable() {
		
		return true;
	}
	
	
	/**
	 * Empty override of superclass method
	 * to ensure that BasicAttack cannot
	 * be unlearned.
	 */
	void unlearn() {

	}

	
	/**
	 * Error messsage, as required by subclass.
	 * Should never come up, but is defined for
	 * safety. 
	 */
	String errorMessage() {
		
		return ("Cannot attack, for some reason.");
	}


	/**
	 * As no resource is spent
	 * when using a BasicAttack,
	 * this method always returns
	 * True. 
	 */
	boolean cost() {
		
		return true;
	}


	protected int quickUse(int damage, Entity target) {

		return target.harm(damage);
	}
	
	protected int quickUse(Entity target) {
		
		return quickUse(scale(), target);
	}


	protected String learnMessage() {
		//this shouldn't come up.
		return "[u] learn[s] how to attack, basically.\n (Because [ps] didn't already know??)";
	}
}
