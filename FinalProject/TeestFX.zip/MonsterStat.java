package finalProject;

/**
 * Stat subclass used exclusively
 * by Monsters, primarily to construct
 * their BasicAttack. Is not used for 
 * any scaling in current implementation. 
 */
public class MonsterStat extends Stat implements Attacking {

	/**
	 * Constructs a new instance of
	 * MonsterStat. As other parameters
	 * are fixed, the only input needed
	 * is the reference of the Monster
	 * using this Stat.
	 * 
	 * @param user Monster object to 
	 * which this MonsterStat is 
	 * assigned.
	 */
	MonsterStat(Monster user) {
		
		super(user, "MonsterStat", Stat.getMaxLevel(), 1);
	}

	/**
	 * Returns the Monster's "special" attack
	 * String. This is intended to allow 
	 * Action-using Monster subclasses to 
	 * have their Action texts use this String
	 * for their "implement." 
	 */
	public String getImplement() {
		
		return ((Monster)getUser()).getSpecialWord();
	}

	/**
	 * Constructs the BasicAttack
	 * deriving from this Stat. Returns
	 * an array of length 1 containing
	 * only that BasicAttack. 
	 */
	protected Action[] buildActions() {
		
		Action[] result = {getBasicAttack()};
		
		return result;
	}


	/**
	 * Returns zero, as this Stat
	 * does not compete with any
	 * others when setting up a 
	 * BasicAttack within the 
	 * current processes of the 
	 * Monster classes. 
	 */
	public int attackPriority() {
		
		return 0;
	}



	public String attackMessage() {
		
		return ("[u] " + ((Monster)getUser()).getAttackVerb() + " [t].\n");
	}


	public BasicAttack getBasicAttack() {

		return new BasicAttack(this);
	}

	/**
	 * Required by superclass but
	 * currently unused, as no 
	 * Monster should have any
	 * procedure to upgrade their
	 * Stat mid-fight (not to 
	 * mention the fact that this
	 * Stat is always constructed
	 * at max level). 
	 */
	protected String upgrade() {

		return null;
	}
}
