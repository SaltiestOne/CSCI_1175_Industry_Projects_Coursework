package finalProject;
/**
 * Abstract class representing some quantifiable, if intangible,
 * aspect of a Fighter. Used for scaling Actions, as
 * well as various parameters and variables within the 
 * Main. Defines a static "maxLevel" parameter representing
 * the highest value that any subclass's level parameter
 * can reach. Level and maxLevel are facilitated via a Gauge
 * object within subclasses, and thus the Gauge class is necessary
 * for instantiating any subclasses.
 * 
 * @author Kayden Barlow
 */
abstract class Stat {
	
	private Entity user;
	private String name;
	private Gauge level;
	private int numActions;
	private static int maxLevel = 5;
	
	/**
	 * Constructor for instances of the Stat
	 * class. Must be assigned to an 
	 * instance of the Entity class.
	 * Objects of this class's subclasses
	 * are necessary to define instances of
	 * Action subclasses. The name paramter will often 
	 * be fixed within a particular subclass.
	 * 
	 * @param user Entity to which the Stat
	 * is assigned.
	 * @param name String name of the Stat.
	 * @param level Integer value of the Stat's
	 * relative power.
	 * @param numActions Integer of the number of
	 * Actions built by this Stat.
	 */
	Stat(Entity user, String name, int level, int numActions) {
		
		this.user = user;
		this.name = name;
		this.level = new Gauge(level, maxLevel);
		this.numActions = Math.min(maxLevel, Math.max(0, numActions));
		this.user.addStat(this);
	}
	

	/**
	 * Returns the reference for the instance
	 * of the Entity class to which the Stat
	 * is assigned.
	 * 
	 * @return Entity user of the Stat.
	 */
	Entity getUser() {
		
		return this.user;
	}
	
	
	/**
	 * Returns the name of the Stat.
	 * 
	 * @return String Stat name.
	 */
	String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the "level" parameter
	 * of the Stat.
	 * 
	 * @return Integer level value.
	 */
	int getLevel() {
		
		return level.getCurrent();
	}
	
	
	/**
	 * Returns a String of the current
	 * and maximum level parameters. If 
	 * these two values are equal, instead
	 * returns "MAX".
	 * 
	 * @return String indicating the current
	 * level parameter relative to its maximum value.
	 */
	String getLevelString() {
		
		if (this.isAtMax()) {
			
			return ("MAX");
		} else {
			
			return level.getGauge();
		}
	}
	
	
	/**
	 * Outputs a message containing the Strings of 
	 * the name parameter and the levelString method.
	 * The Boolean "enter" input determines
	 * if the output message is formatted with a line break 
	 * or a simple space between the name and level data. 
	 * 
	 * @param enter Boolean representing if the output
	 * String should have a line break.
	 * 
	 * @return String containing information about the Stat's
	 * name and level.
	 */
	String menuMessage(boolean enter) {
		
		if (enter) {
		
			return (this.getName() + "\n(Level " + this.getLevelString() +")");
		} else {
			
			return (this.getName() + " (Level " + this.getLevelString() +")");
		}
	}

	
	/**
	 * Returns a "scaled" integer value
	 * derived from the level parameter of 
	 * both the Stat and its assigned Fighter, 
	 * equal the level of the Stat multiplied by
	 * its relative potency, plus the level of 
	 * its user.
	 * 
	 * @return Integer scaled this Stat's level 
	 * and potency, and its user's level.
	 */
	int getModdedLevel() {
		
		return (((getLevel() * potency()) + user.getLevel()));
	}
	
	
	/**
	 * Sets the level parameter to the 
	 * input integer value. Level cannot
	 * be negative or above the static 
	 * maxLevel parameter, as faciliated
	 * by the Gauge class.
	 * 
	 * @param level Integer new value of
	 * level parameter.
	 */
	void setLevel(int level) {
		
		this.level.setCurrent(level);
	}
	
	
	/**
	 * Increments the level parameter and returns
	 * a message describing the effects of such 
	 * (potentially including new Actions learned).
	 * Methods within the facilitating Gauge class
	 * ensure that the new level does not exceed the 
	 * static maxLevel parameter. 
	 * 
	 * @return String message describing the effects
	 * of the level-up.
	 */
	public String upLevel()	{
		
		this.setLevel(this.getLevel() + 1);
		
		return getUser().formatMessage(upgrade());
	}
	
	
	/**
	 * Indicates if the Stat subclass's 
	 * level paramter has reached the 
	 * maximum allowed.
	 * 
	 * @return True if level is equal to
	 * its maximum value, False otherwise.
	 */
	boolean isAtMax() {
		
		return (level.isFull());
	}
	
	
	/**
	 * Returns the value of the maximum value
	 * allowed for any subclass's level parameter.
	 * 
	 * @return Integer of the value of the
	 * static maxLevel parameter.
	 */
	static int getMaxLevel() {
		
		return Stat.maxLevel;
	}
	
	
	/**
	 * Sends Actions built from this stat
	 * to the Entity using this Stat. 
	 * Will not send Actions to non-ActionUser
	 * Entities. 
	 */
	public void addActions() {
		
		if (user instanceof ActionUser) {
			
			Action[] actions = buildActions();
		
			for (int a = 0; a < actions.length; a++) {
				
				((ActionUser)getUser()).addAction(actions[a]);
			}
			
		} else {}
	}
	
	
	
	/**
	 * Returns the numActions parameter,
	 * representing the number of Actions
	 * built by this Stat.
	 * 
	 * @return Integer representing the
	 * number of Actions built by this Stat.
	 */
	protected int getNumActions() {
		
		return numActions;
	}
	
	
	/**
	 * Returns the integer representing
	 * the relative effect on scaling compared
	 * to other Stats (independant of level).
	 * By default, is inversly proportional
	 * to the number of Actions built by the 
	 * Stat. 
	 * 
	 * @return Integer used to compared scaling
	 * with other Stats.
	 */
	protected int potency() {
		
		return maxLevel - numActions + 1;
	}
	
	
	/**
	 * Returns a String containing information
	 * about the thing that this Stat uses to
	 * facilitate Actions. By defualt, is just the 
	 * Stat's name parameter.
	 *  
	 * @return String describing the Stat.
	 */
	public String getImplement() {
		
		return getName();
	}

	
	
	/**
	 * Constructs a list of Actions
	 * deriving from this Stat. 
	 * 
	 * @return Action[] containing all
	 * Actions scaled from this Stat.
	 */
	protected abstract Action[] buildActions();
	
	
	/**
	 * Facilitates the results of increasing the
	 * Stat's level, which may include learning
	 * Actions or changing flavor. Should not,
	 * in and of itself, increment the level
	 * parameter.
	 * 
	 * @return String describing the effects of 
	 * a level-up.
	 */
	abstract protected String upgrade();
}
