package finalProject;

/**
 * A abstract subclass of Stat representing more
 * tangible traits of a Fighter, namely
 * specific tools (or categories of tools)
 * at the Fighter's disposal. Differs from
 * its parent in output naming and formatting,
 * but not in scaling.
 * 
 * @author Kayden Barlow
 */
abstract class Gear extends Stat {
	
	private String[] items;
	private int itemLevel;

	/**
	 * Constructor for instances of the Gear
	 * class. Must be assigned to an 
	 * instance of the Fighter class.
	 * May be used to define instances of the
	 * Action class, with some potentially 
	 * requiring concrete subclasses of this 
	 * specific Stat subclass. Requires a String
	 * array of one or more "implements" which 
	 * the Gear object is meant to represent.
	 * An "itemLevel" integer parameter is 
	 * created to distinquish between different 
	 * entries on this array, which is 0 
	 * (i.e., the first) on construction.
	 * 
	 * @param user Fighter to which the Gear
	 * is assigned.
	 * @param name String name.
	 * @param level Integer value of the Gear's
	 * relative power.
	 * @param numSkills	Integer equal to the number
	 * of Skill Actions built from this Gear Stat.
	 * @param items String array of one or more 
	 * of the specific implements "expressed" as
	 * this instance of Gear.
	 */
	Gear(Entity user, String name, int level, int numSkills, String[] items) {
		
		super(user, name, level, numSkills);
		this.items = items;
		this.itemLevel = 0;
	}

	
	/**
	 * Overrides the Stat implement method
	 * to instead return the name of the current
	 * selection of the items parameter.
	 */
	public String getImplement() {
		
		return items[itemLevel];
	}

	
	
	
	protected String upgrade() {
		
		String emptyLevel = ("[u] hone[s] [pf] further with [pp] " + getImplement() + ".\n");
		//TODO: make a more dynamic formula for Action-learning levels
		if ((getLevel() % 2) == 0) {
		
			try {
				
				return (((Hero)getUser()).learnFromStat(this).learnMessage());
			} catch (IllegalArgumentException ex) {
				
				return emptyLevel;
			}
		} else {
			
			if (upItem()) {
				
				return ("[u] seek[s] out a new " + getName() + 
						",\n and procure[s] a " + getImplement() + ".\n");
			} else {
				
				return emptyLevel;
			}
		}
	}
	
	
	
	/**
	 * Increments the itemLevel parameter,
	 * designating the next entry in the 
	 * "items" array as the new levelName.
	 * itemLevel cannot exceed the length
	 * of the array. Returns a boolean value
	 * based on whether or not the value
	 * increased, this in intended to be used
	 * by calling methods. However, the method
	 * can be treated as void if desired.
	 * 
	 * @return True if itemLevel increased,
	 * False otherwise.
	 */
	boolean upItem() {
		
		if (this.itemLevel < (this.items.length - 1)) {
			
			this.itemLevel++;
			
			return true;
		} else {
			
			return false;
		}
	}
	
	
	/**
	 * Outputs a String containing the Gear's
	 * name parameter, its levelname method
	 * (which therefore includes its current item name),
	 * as well as the Gauge representing its current and max
	 * level parameter. The Boolean "enter" input determines
	 * if the output message is formatted with a line break 
	 * or a simple space between the implement name and level data. 
	 * 
	 * @param enter Boolean representing if the output
	 * String should have a line break.
	 * 
	 * @return String containing information about the Gear's
	 * name and level.
	 */
	String menuMessage(boolean enter) {
		
		if (enter) {
			
			return (this.getImplement() + "\n(" + this.getName() + " " 
				+ this.getLevelString() + ")");
		
		} else {
			return (this.getImplement() + " (" + this.getName() + " " 
				+ this.getLevelString() + ")");
		}
	}
}
