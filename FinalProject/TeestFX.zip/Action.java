package finalProject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * An abstract class for the various Actions
 * that the Hero can perform. The specifics,
 * including resource costs, are left for 
 * concrete subclasses to define.
 * 
 * @author Kayden Barlow
 */
abstract class Action {
	
	
	private String name;
	private boolean learned = false;
	private int cost;
	private int damage = 0;
	private Stat stat;
	private ActionDoer doer = null;
	private DamageScaler scaler = null;
	private String typeName;
	
	/**
	 * The constructor for any concrete subclass instances
	 * of the abstract Action class.
	 * 
	 * @param name String of the Action's name. Should be identical
	 * to one on the AllActions list if convenience methods from that 
	 * class are to be invoked.
	 * @param cost Integer for the Action's resources cost, used 
	 * and invoked differently according to its concrete type.
	 * @param stat The Stat object from which the Action's scaling is derived.
	 * @param learned Boolean value indicating if the player has "learned" this
	 * skill after its creation. If False, the Action cannot be used regardless 
	 * of other factors.
	 * @param typeName String indication the name of the Action's subclass. Should
	 * be invoked by these subclasses, but not alterable by their constructors.
	 */
	Action (String name, int cost, Stat stat, boolean learned, String typeName) {
		
		this.name = name;
		this.cost = cost;
		this.stat = stat;
		this.learned = learned;
		this.typeName = typeName;
	}
	
	/**
	 * The constructor for any concrete subclass instances
	 * of the abstract Action class.
	 * 
	 * @param name String of the Action's name. Should be identical
	 * to one on the AllActions list if the addDoer parameter is set
	 * to True.
	 * @param addDoer Boolean determining if the name parameter is to
	 * be used to find and add an ActionDoer to the new Action.
	 * @param cost Integer for the Action's resources cost, used 
	 * and invoked differently according to its concrete type.
	 * @param stat The Stat object from which the Action's scaling is derived.
	 * @param learned Boolean value indicating if the player has "learned" this
	 * skill after its creation. If False, the Action cannot be used regardless 
	 * of other factors.
	 * @param typeName String indication the name of the Action's subclass. Should
	 * be invoked by these subclasses, but not alterable by their constructors.
	 */
	Action (String name, boolean addDoer, int cost, Stat stat, boolean learned, String typeName) {
		
		this (name, cost, stat, learned, typeName);
		
		if (addDoer) {
			
			try {
				
				this.setActionDoer(AllActions.getDoer(name));
			} catch (IllegalArgumentException ex) {
				//TODO: hey an actual procedure might be good here
			}
		} else {}
	}
	
	
	/**
	 * Retrieves the name of the Action
	 * subclass to which this Action belongs.
	 * 
	 * @return String indicating the name of
	 * this Action's subclass.
	 */
	public String getTypeName() {
		
		return typeName;
	}
	
	
	/**
	 * Returns the Action's name parameter.
	 * 
	 * @return String of the Action's name.
	 */
	String getName() {
		
		return name;
	}
	
	
	/**
	 * Returns the "implement," or variable
	 * means by which the Action is "used." Gives
	 * the name of the Stat tied to the Action,
	 * but is itended to be overwritten in subclasses
	 * requiring Gear Stats to give the name of
	 * the specific "piece" of equipment used.
	 * 
	 * @return String of the "thing" used by the Action.
	 */
	String getImplement() {
		
		return this.stat.getImplement();
	}
	
	

	
	/**
	 * Returns the Action's resource cost. How this is used
	 * is intended to be defined by subclasses.
	 * 
	 * @return Integer value of the Action's resource cost.
	 */
	int getCost() {
		
		return cost;
	}
	
	
	/*
	int getDamage() {
		
		return damage;
	}
	/*
	protected int setDamage(int damage) {
		
		this.damage = damage;
		
		return damage;
	}
	
	
	int setDamage() {
		
		return setDamage(scale());
	}
	*/


	
	/**
	 * Indicates if the Action has been learned.
	 * 
	 * @return True if the Action is learned, False if not.
	 */
	boolean isLearned() {
		
		return learned;
	}
	
	
	/**
	 * Sets the Action's "learned" value to True,
	 * indicating that the player has gained the
	 * ability to use it.
	 * 
	 */
	void learn() {
		
		this.learned = true;
	}
	
	
	/**
	 * Sets the Action's "learned" value to False,
	 * removing the player's ability to use it. I
	 * have no plans to use this, but hey, futureproofing.
	 * 
	 */
	void unlearn() {
		
		this.learned = false;
	}
	
	/**
	 * Returns the reference to the Action's 
	 * associated Stat object. Only returns the 
	 * reference, further parameters and methods
	 * must be invoked afterwards.
	 * 
	 * @return Reference of the Stat object 
	 * associated with this Action.
	 */
	Stat getStat() {
		
		return this.stat;
	}
	
	
	/**
	 * Returns the reference to the ActionUser Entity
	 * associated with the Stat object associated 
	 * with this skill, which is therefore also the 
	 * "user" of the skill. Useful as a shortcut for 
	 * Actions that affect their user directly.
	 * 
	 * @return Reference of the ActionUser object 
	 * associated with the Stat 
	 * object associated with this Action.
	 */
	ActionUser getUser() {
		
		return (ActionUser)this.stat.getUser();
	}
	
	
	/**
	 * Assigns a DamageScaler object
	 * to this Action. This will be invoked
	 * to determine the "potency" of the 
	 * Action's effects. Lambda compatible. 
	 * 
	 * @param scaler DamageScaler object 
	 * affecting the scaling of the Action.
	 */
	public void addDamageScaler(DamageScaler scaler) {
		
		this.scaler = scaler;
	}
	
	
	/**
	 * Assigns a DamageScaler object to
	 * this Action using the default
	 * "damage" formula found in the 
	 * Scaler class.
	 * 
	 * @param scaler Integer to be used
	 * to scale from the Scaler class.
	 */
	public void addDamageScaler(int scaler) {
		
		addDamageScaler(e -> {
			
			return Scaler.damage(scaler);});
	}
	
	
	/**
	 * Returns a value scaled from this Action's
	 * assigned DamageScaler lambda. If none has
	 * been assigned, calls for the Scaler class.
	 * 
	 * @return Integer 
	 */
	protected int scale() {
		
		if (scaler == null) {
			
			return Scaler.damage(this.getStat());
		} else {
			
			return scaler.damage(this);
		}
	}
	
	
	/**
	 * Sets this Action with an ActionDoer to 
	 * facilitate its individual effects. Will
	 * usually match the name of the Action.
	 * 
	 * @param actionDoer ActionDoer creating the 
	 * unique effects of this Action.
	 */
	public void setActionDoer(ActionDoer actionDoer) {
		
		this.doer = actionDoer;
	}

	
	/**
	 * Handles the effects of this Action according
	 * to is ActionDoer, and returns a String describing
	 * the effects of such. Will throw an exception if
	 * no Doer was added.
	 * 
	 * @param target Entity targeted by this Action.
	 * @return String describing the Action's effect.
	 */
	public String doAction(Entity target) {
		
		if (isUsable()) {
			
			if (doer == null) {
			
				throw new IllegalArgumentException("Action \"" + getName() + "\" not properly constructed.");
			} else {
			
				return formatMessage(doer.doinguAcushun(this, target), target);
			}
		} else {
			
			throw new IllegalArgumentException(errorMessage());
		}	
	}
	
	/**
	 * Formats the input message, replacing certain
	 * substrings with words determined by parameters
	 * of this Action, its Stat, and its User. Should
	 * be invoked on most Strings output by an Action. 
	 * 
	 * @param message String to be modified.
	 * @return Formatted String.
	 */
	private String formatMessage(String message) {
		
		message = getUser().formatMessage(message);
		message = message.replace("[i]", getImplement());
		
		return message;
	}
	
	/**
	 * Formats the input message, replacing certain
	 * substrings with words determined by parameters
	 * of this Action, its Stat, and its User, as well
	 * as the targeted Enitity's parameters. Should
	 * be invoked on most Strings output by an Action. 
	 * 
	 * @param message String to be modified.
	 * @param target Entity targeted by this Action.
	 * @return Formatted String.
	 */
	private String formatMessage(String message, Entity target) {
		
		return formatMessage(message).replace("[t]", target.getPerspectiveName());
	}
	
	
	
	/**
	 * Abstract method indicating if the Action can be used.
	 * As this may involve the resource costs and other
	 * restrictions of subclasses, this is left abstract for
	 * them to define. In most cases, should return False 
	 * regardless of other considerations if the Action is 
	 * unlearned.
	 * 
	 * @return True if the Action can currently be used,
	 * False otherwise.
	 */
	abstract boolean isUsable();
	
	
	/**
	 * Abstract method returning a String with info on
	 * the specific Action, intended for use in a list of 
	 * possible Actions. Should include the name as well
	 * as resource cost and other relevant use info. As this 
	 * info will depend on the Action's subclass, the 
	 * method is left abstract.
	 * 
	 * @return String with info on the use of the Action.
	 */
	abstract String menuMessage();
	
	
	/**
	 * Abstract method used to provide String descriptions
	 * for exceptions thrown as a result of invalid Actions.
	 * As usability is a factor, this method is left abstract. 
	 * 
	 * @return String description of why this Action is
	 * unusable.
	 */
	abstract String errorMessage();
	
	
	/**
	 * Returns a message describing
	 * that the user has learned this
	 * Action, varying based on type. 
	 * 
	 * @return String describing the 
	 * attainment of this Action based
	 * on its subclass.
	 */
	abstract protected String learnMessage();
	
	
	/**
	 * Consolidation method for
	 * handling whatever procedures
	 * involve spending or using
	 * resource costs. Is not called
	 * for in the general doAction
	 * method, allowing for the 
	 * freedom to control costs within
	 * an ActionDoer.
	 * 
	 * @return True if resource was
	 * available and spent, False 
	 * otherwise.
	 */
	abstract boolean cost();
	
	
	/**
	 * Abstract method meant to consolidate "common" methods
	 * used by Action subclasses, such as damage protocol
	 * and resource manipulation. Returns the integer of damage
	 * used by the input.
	 * 
	 * @param damage Integer as defined by subclass.
	 * @param target Entity targeted by this Action.
	 * @return Integer as defined by subclass.
	 */
	abstract protected int quickUse(int damage, Entity target);
	
	/**
	 * Abstract method meant to consolidate "common" methods
	 * used by Action subclasses, such as damage protocol
	 * and resource manipulation. 
	 * 
	 * @param target Entity targeted by this Action.
	 * @return Integer as defined by subclass.
	 */
	abstract protected int quickUse(Entity target);
}