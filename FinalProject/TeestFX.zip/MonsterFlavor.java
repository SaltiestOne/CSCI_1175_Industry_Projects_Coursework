package finalProject;

/**
 * Class containing the various
 * Strings needed to properly 
 * "bring a Monster to life," as
 * it were.  
 * 
 * @author Kayden Barlow
 */
public class MonsterFlavor {

	private String[] flavors = new String[5];
	
	/**
	 * Constructs a new instance of
	 * MonsterFlavor. 
	 */
	MonsterFlavor() {}
	
	/**
	 * Sets a String to be called for
	 * when outputing status text.
	 * Should be about two lines in length,
	 * but is not required to be. 
	 * 
	 * @param flavor String to be used as 
	 * the "status message" flavor text.
	 */
	public void setStatusText(String flavor) {
		
		flavors[3] = flavor;
	}
	
	
	/**
	 * Returns the String set to be the flavor
	 * text status message. Defaults to a 
	 * different message if none has been set.
	 * 
	 * @return String status text.
	 */
	public String getStatusText() {
		
		return defaultString((flavors[3]), 
				("You don't know what this is.\nNeither does Kayden."));
	}
	
	
	/**
	 * Sets the word to be used
	 * when describing the Monster's
	 * basic attack. Should be a verb
	 * fitting the syntax "x [String] y,"
	 * including conjugation.
	 * 
	 * @param verb String of the word(s)
	 * describing an attack.
	 */
	public void setAttackVerb(String verb) {
		
		flavors[1] = verb;
	}
	
	/**
	 * Returns the word describing a 
	 * basic attack. Defaults to a simple
	 * "attacks" if no attack verb has
	 * been set.
	 * 
	 * @return String describing an 
	 * attack.
	 */
	public String getAttackVerb() {
		
		return defaultString(flavors[1], "attack[s]");
	}
	
	/**
	 * Sets the "special" word. The usage 
	 * (and part of speech) may vary with
	 * subclass.
	 * 
	 * @param special String used in
	 * describing the Monster's special
	 * attack.
	 */
	public void setSpecial(String special) {
		
		flavors[2] = special;
	}
	
	/**
	 * Returns the String used in
	 * describing the Monster's special
	 * attack. Defaults to the attack 
	 * verb if none has been set.
	 * 
	 * @return String used in
	 * describing the Monster's special
	 * attack.
	 */
	public String getSpecial() {
		
		return defaultString(flavors[2], getAttackVerb());
	}
	
	
	/**
	 * A safety method used to ensure that
	 * a null String is not output. Each 
	 * String-returning method in this class
	 * calls for this. If the first parameter
	 * is null, the "default" second parameter
	 * is used instead. The second parameter
	 * should always be set to a fixed String 
	 * per method, and not a variable or call,
	 * to prevent a "double-null".
	 * 
	 * @param override String that would be 
	 * preferred to be output, but which cannot
	 * be garanteed to exist.
	 * @param def String to be output if the 
	 * first parameter is null.
	 * @return String according to parameters.
	 */
	private String defaultString(String override, String def) {
		
		if (override == null) {
			
			return def;
		} else {
			
			return override;
		}
	}
}
