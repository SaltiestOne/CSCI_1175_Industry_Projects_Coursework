package finalProject;

/**
 * Class for FormattedButtons representing specific
 * Action instances. While the Button is intended 
 * to be used to execute said action, the procedure 
 * for that must be defined externally. Implements 
 * the PaintableButton interface to update the 
 * displayed text as the usability and other
 * conditions of the Action shift. As a subclass of
 * the FormattedButton class, requires the presence of
 * the Formatter class to work.
 * 
 * @author Kayden Barlow
 */
public class ActionButton extends FormattedButton implements PaintableButton {

	Action action;
	
	/**
	 * Constructor for instances of the 
	 * ActionButton class. Creates a Paintable,
	 * FormattedButton from a specific Action
	 * object. Automatically invokes the Paint()
	 * method to display its Action's MenuMessage 
	 * String.
	 * 
	 * @param action Action object to which this
	 * Button will be assigned.
	 */
	ActionButton(Action action) {
		
		super();
		this.action = action;
		this.paint();
	}
	
	
	/**
	 * Constructor for instances of the 
	 * ActionButton class. Creates a Paintable,
	 * FormattedButton from a specific Action
	 * object, with a text size determined by the
	 * integer input. Automatically invokes the 
	 * Paint() method to display its Action's 
	 * MenuMessage String.
	 * 
	 * @param action Action object to which this
	 * Button will be assigned
	 * @param size Integer value for the size of 
	 * the Button's text.
	 */
	ActionButton(Action action, int size) {
		
		super(" ", size);
		this.action = action;
		this.paint();
	}
	
	
	/**
	 * Returns the Action parameter to
	 * which this Button is assigned.
	 * 
	 * @return Action parameter of this 
	 * Button.
	 */
	public Action getAction() {
		
		return this.action;
	}
	
	
	/**
	 * As required by the PaintableButton
	 * interface, "paints" the text of the 
	 * Button. Calls for the Action parameter's
	 * MenuMessage, and adjusts the color of
	 * the text based on the Action's "learned"
	 * parameter and isUsable() methods. 
	 * Potential colors are defined in the 
	 * Formatter object.
	 */
	public void paint() {

		this.setText(this.action.menuMessage());

		if (this.action.isLearned()) {

			this.setFont(Formatter.getBoldFont());
			
			if (this.action.isUsable()) {
				
				this.setTextFill(Formatter.getMainColor());
			} else {
				
				this.setTextFill(Formatter.getWarnColor());
			}
		} else {

			this.setFont(Formatter.getFont());
			
			this.setTextFill(Formatter.getFadeColor());
		}
	}
}
