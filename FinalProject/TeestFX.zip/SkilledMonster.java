package finalProject;

public class SkilledMonster extends Monster implements SkillUser {

	int cooldown = 0;
	Skill skill;
	
	SkilledMonster(String name, String flavor, int level, int maxHealth) {
		
		super(name, flavor, level, maxHealth);
	}
	
	SkilledMonster(String name, String flavor, int level, int maxHealth, Skill skill) {
		
		this(name, flavor, level, maxHealth);
		
		setSkill(skill);
	}
	
	SkilledMonster(String name, MonsterFlavor flavor, int level, int maxHealth) {
		
		super(name, flavor, level, maxHealth);
	}
	
	SkilledMonster(String name, MonsterFlavor flavor, int level, int maxHealth, Skill skill) {
		
		this(name, flavor, level, maxHealth);
		
		setSkill(skill);
	}
	
	public void setSkill(Skill skill) {
		
		this.skill = skill;
		
		this.skill.addDamageScaler((e -> {return Scaler.monsterDamage(getLevel() + 1);}));
		
		specialProcedure();
	}


	/**
	 * Returns the integer representing
	 * the number of turns remaining until
	 * this Monster can use another Skill. 
	 * 
	 * @return Integer value of cooldown.
	 */
	public int getCooldown() {

		return cooldown;
	}

	
	/**
	 * Returns a boolean indicating if
	 * cooldown is a positive value, 
	 * and therefor that Skills are on 
	 * cooldown.
	 * 
	 * @return True if cooldown is greater than
	 * zero, False if it is zero (or less, somehow).
	 */
	public boolean isOnCooldown() {

		return (cooldown > 0);
	}

	/**
	 * Sets Cooldown to the specified value.
	 * Cooldown cannot be negative.
	 * 
	 * @param cooldown Integer new Cooldown.
	 */
	public void setCooldown(int cooldown) {

		this.cooldown = (Math.max(cooldown, 0));
	}

	/**
	 * Invokes its sister method to drop
	 * Cooldown by 1. Intended to be invoked at
	 * the end of every turn.
	 */
	public void dropCooldown() {
	
		if (isOnCooldown()) {
			
			cooldown--;
		} else {}		
	}


	/**
	 * Reduces Cooldown value by the input
	 * amount. Cooldown cannot be negative.
	 * 
	 * @param decrement Integer amount to reduce
	 * Cooldown.
	 */
	public void dropCooldown(int decrement) {

		if (decrement < cooldown) {
		
			cooldown = (cooldown - decrement);
		} else {
			
			cooldown = 0;
		}
	}
	
	
	protected boolean specialProcedure() {
		
		dropCooldown();
		
		try {
			
			if (skill.isUsable()) {
				
				if ((getHealth() <= (getMaxHealth() / 4))) {
				
					return setSpecial(true);
				
				} else {
					
					return setSpecial(new java.util.Random().nextBoolean());
				}
			} else {
				
				return setSpecial(false);
			}
		} catch (NullPointerException ex) {
			//in case the Skill has not been set yet.
			return false;
		}
	}
	
	public String action(Entity target) {
		
		if (isStunned()) {
			
			return stunnedMessage(target);
		} else if (isOnSpecial()) {
			
			if(isOnCooldown()) {
				
				return (getPerspectiveName() + " is unable to use thier technique.\n\n");
			} else {
				
				return skill.doAction(target);
			}
		} else {
			
			return doBasic(target);
		}	
	}
	
	
}
