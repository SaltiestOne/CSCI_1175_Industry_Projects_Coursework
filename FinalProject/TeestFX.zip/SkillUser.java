package finalProject;

/**
 * Interface marking that this ActionUser
 * Entity uses Skills. 
 * 
 * @author Kayden Barlow
 */
interface SkillUser extends ActionUser {

	/**
	 * Returns the integer representing
	 * the number of turns remaining until
	 * this ActionUser can use another Skill.
	 * (If the user can use other types of
	 * Actions, they will be unaffected by
	 * this restriction).
	 * 
	 * @return Integer value of cooldown.
	 */
	int getCooldown();
	
	/**
	 * Returns a boolean indicating if
	 * cooldown is a positive value, 
	 * and therefor that Skills are on 
	 * cooldown.
	 * 
	 * @return True if cooldown is greater than
	 * zero, False if it is zero (or less, somehow).
	 */
	boolean isOnCooldown();
	
	/**
	 * Sets Cooldown to the specified value.
	 * Cooldown should not be negative.
	 * 
	 * @param cooldown Integer new Cooldown.
	 */
	void setCooldown(int cooldown);
	
	/**
	 * Drops Cooldown by 1. Intended to be 
	 * invoked at the end of every turn.
	 */
	public void dropCooldown();
	
	/**
	 * Reduces Cooldown value by the input
	 * amount. Cooldown cannot be negative.
	 * 
	 * @param decrement Integer amount to reduce
	 * Cooldown.
	 */
	void dropCooldown(int decrement);
	
}
