package finalProject;

import java.util.Random;

/**
 * Concrete Stat subclass meant to represent a Fighter's 
 * talent with some unspecified type of magic. Intended to
 * define and scale Spell objects. Implements ManaScale
 * to affect an associated Fighter's Mana parameter.
 * As with all Stat subclasses, the level parameter and 
 * the static maxLevel value are facilitated via a Gauge
 * object, and thus the Gauge class is necessary
 * for instantiating any objects of this class.
 * 
 * @author Kayden Barlow
 */
public class Magic extends Stat implements ManaScale, Attacking {

	
	/**
	 * Constructor for instances of the Magic
	 * class. Must be assigned to an 
	 * instance of the Caster class, and will
	 * be added to that Caster's list
	 * of stats. The name parameter will be fixed
	 * as "Magic".
	 * 
	 * @param user Caster to which the Stat
	 * is assigned.
	 * @param level Integer value of the Stat's
	 * relative power.
	 */
	Magic(Caster user, int level) {
		
		super(user, "Magic", level, 5);
	}
	
	
	/**
	 * Creates a instance of this object with
	 * a level parameter of zero. As the superclass
	 * constructor automatically adds new Stat objects
	 * to the Fighter's list of stats, this is intended
	 * to be used to quickly add a new, generic Magic
	 * Stat to the input Fighter.
	 * 
	 * @param user Fighter to receive a new instance
	 * of this object.
	 */
	static void add(Caster user) {
		
		new Magic(user, 0);
	}
	
	
	/**
	 * As required by the ManaScale interface,
	 * returns a value intended to scale the 
	 * maxMana parameter of this object's associated
	 * Fighter instance. In this case, it returns
	 * three times the value of the level parameter
	 * of this object.
	 * 
	 * @return Integer scaled from this Magic object's
	 * level.
	 */
	public int manaScale() {
		
		return (this.getLevel() * 3);
	}
	
	
	 /**
	  * Returns a String based on the Magic
	  * object's level parameter, indicating
	  * the number of spells known.
	  * 
	  * @return String of the number of 
	  * spells known.
	  *
	public String getImplement() {
		
		if (getLevel() == 0) {
			
			return "No Spells known.";
		} else if (getLevel() == 1) {
			
			return "1 Spell known.";
		} else {
			
			return (getLevel() + " Spells known.");
		}
	}*/
	
	
	
	/**
	 * Outputs a message containing the Strings of 
	 * the name parameter and the levelString method, which
	 * in this case should be equal to the number of spells
	 * known by the Hero. The Boolean "enter" input determines
	 * if the output message is formatted with a line break 
	 * or a simple space between the name and level String.
	 * 
	 * @param enter Boolean representing if the output
	 * String should have a line break.
	 * 
	 * @return String containing information about the Magic
	 * Stat's name and level.
	 */
	String menuMessage(boolean enter) {
		
		if (enter) {
		
			return (this.getName() + "\n(" + this.getLevelString() +" Spells)");
		} else {
			
			return (this.getName() + " (" + this.getLevelString() + " Spells)");
		}
	}
	
	
	/**
	 * Integer value determing
	 * which Attacking stat has priority
	 * to create and assign its BasicAttack
	 * in the event that an Entity has
	 * more than one Attacking Stat assigned.
	 * Is equal to the Scaling value, as is 
	 * typical.
	 * 
	 * @return Integer value of the relative
	 * priority of this Attacking Stat over
	 * any others.
	 */
	public int attackPriority() {
		
		return potency();
	}



	/**
	 * String used to construct the 
	 * message returned when using the
	 * BasicAttack generated from this
	 * Attacking Stat.
	 * 
	 * @return String displayed when
	 * attacking with this Attacking Stat.
	 */
	public String attackMessage() {
		
		return ("[u] blast[s] [t] with magic bolts.\n");
	}

	
	
	/**
	 * Constructs the BasicAttack
	 * based on this Attacking Stat. 
	 * 
	 * @return BasicAttack derived from
	 * this Attacking Stat.
	 */
	public BasicAttack getBasicAttack() {
		
		return new BasicAttack((Attacking)this);
	}
	
	
	
	protected Spell[] buildActions() {
		
		Spell[] result = new Spell[getNumActions()];
		
		int[] costs = {4, 2, 0, 8, 5};
		
		String[] name = {"Drain","Bolt","Ascend","Revert","Astra"};
			
		DamageScaler[] scalers = {(e -> {return Scaler.damage(e.getUser().getLevel());}),
				(e -> {return Scaler.damage(e.getStat().getModdedLevel());}),
				(e -> {return Scaler.damage(e.getUser().getLevel());}),
				(e -> {return Scaler.damage((e.getStat().getLevel() + e.getStat().getLevel()), 
							e.getUser().getLevel());}),
				(e -> {return Scaler.damage(1, (int)(e.getStat().getLevel() * 2.5));})};
		
		
		for (int a = 0; a < result.length; a++) {
			
			result[a] = new Spell(name[a], true, costs[a], this, false);
			
			result[a].addDamageScaler(scalers[a]);
		}
		
		return result;
	}


	
	protected String upgrade() {

		String emptyLevel = ("[u] further delve[s] into the art of " + getName() + ".\n\n");
		//TODO: find better formula (see Gear)
		if (true) {
			
			try {
				
				return ("[u] practice[s] [pp] " + getName() + ",\n and learn[s] how to cast " +
				 ((Hero)getUser()).learnFromStat(this).getName() + ".\n");
			} catch (IllegalArgumentException ex) {
				
				return emptyLevel;
			}
		} else {
			
			return emptyLevel;
		}
	}

}
