package finalProject;
/**
 * Interface indicating the implementing object
 * (typically a Stat subclass) affects the scaling
 * of a Fighter's maxMana parameter. 
 * 
 * @author Kayden Barlow
 */
public interface ManaScale {

	/**
	 * Grabs an integer as defined by the implementing
	 * object, typically scaling from one of the Stat
	 * subclass object's parameters.
	 * 
	 * @return Integer to be used in scaling a Fighter's
	 * maxMana paramter.
	 */
	public int manaScale();
}
