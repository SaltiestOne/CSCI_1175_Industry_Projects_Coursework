package finalProject;

import java.util.Random;


/**
 * Subclass of Monster that
 * is able to cast Spells.
 * 
 * @author Kayden Barlow
 */
public class Spellcaster extends Monster implements Caster {
	
	private Spell spell;
	private boolean silenced;
	private Gauge mana;

	Spellcaster(String name, MonsterFlavor flavor, int level, int maxHealth, Spell spell) {
		
		this(name, flavor, level, maxHealth);
		
		this.spell = spell;
	}
	
	Spellcaster(String name, MonsterFlavor flavor, int level, int maxHealth) {
		
		super(name, flavor, level, maxHealth);
		
		mana = new Gauge(getLevel() * 3);
	}
	
	public void setSpell(Spell spell) {
		
		this.spell = spell;
		
		this.spell.addDamageScaler((e -> {return Scaler.monsterDamage(getLevel() + 1);}));
		
		specialProcedure();
	}
	
	public String disable(int potency) {
		
		potency = ((potency * mana.getMax()) / getMaxHealth());
		
		mana.adjust(-potency);
		
		silenced = true;
		
		return (potency + " Mana");
	}
	
	/*
	public boolean isDisabled() {
		
		if (mana.getCurrent() < spell.getCost()) {
			
			return true;
		} else {
			
			return false;
		}
	}*/
	
	
	protected boolean specialProcedure() {
		
		try {
			
			if (spell.isUsable()) {
			
				if (getHealth() < ((getMaxHealth() / 5))) {
					//"desperation" attack
					return setSpecial(true);
				} else if (mana.getCurrent() < (spell.getCost() * 2)) {
					//saves a spell for the desperation attack
					return setSpecial(false);
				} else {
					//otherwise, one-in-two chance
					return setSpecial(new Random().nextBoolean());
				}
			} else {
				
				return setSpecial(false);
			}
		} catch (NullPointerException ex) {
			//in case the Spell has not been set.
			return false;
		}
	}
	
	
	public String action(Entity target) {
		
		if (isStunned()) {
			
			return stunnedMessage(target);
			
		} else if (isOnSpecial() && !isDead()) {
			
			if (spell.isUsable()) {

				return spell.doAction(target);
			} else {
				
				return (getPerspectiveName() + " is unable to cast spells...\n\n");
			}
		} else {
			
			return doBasic(target);
		}
	}

	
	
	public void setMaxMana(int maxMana, boolean maximize) {

		mana.setMax(maxMana, maximize);
	}


	public int getMaxMana() {
		
		return mana.getMax();
	}

	
	public void setMana(int mana) {

		this.mana.setCurrent(mana);
	}

	public void adjustMana(int mana) {

		this.mana.adjust(mana);
	}

	
	public int getMana() {
	
		return mana.getCurrent();
	}

	/**
	 * Attempts to reduce current Mana by
	 * the input amount. Returns a Boolean
	 * indicating if Mana was spent.
	 * 
	 * @param amount Integer reduction in current Mana.
	 * @return Boolean True if Mana was sufficient and
	 * was spent, False otherwise.
	 *
	public boolean spendMana(int amount) {

		if (amount > getMana()) {
			
			return false;
		} else {
			
			mana.adjust(-amount);
			
			return true;
		}
	}*/
}