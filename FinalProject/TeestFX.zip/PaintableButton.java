package finalProject;
/**
 * Interface indicating the implementing
 * Button (or other Node) displays dynamic
 * information that may need to be 
 * periodically updated by "Painting" its
 * visual components.
 * 
 * @author Kayden Barlow
 */
public interface PaintableButton {

	
	/**
	 * Calls a repeatable method to adjust
	 * the visual output of a Button (or
	 * other Node) on the assumption that
	 * it may have changed. Will often be
	 * invoked by the object's constructor
	 * for convenience. 
	 */
	public void paint();
}
