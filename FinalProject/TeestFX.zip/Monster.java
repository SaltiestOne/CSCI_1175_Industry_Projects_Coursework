package finalProject;
import java.util.Random;


/**
 * Subclass of Fighter representing the enemies that the
 * Hero will fight. Requires a String array for its constructor,
 * which includes its name, attack verbs, and a flavorful decription.
 * (How "monstrous" some of these enemies are will be left for the 
 * reader's ideology to determine). The Gauge class is required, as
 * with all Fighter subclasses, as is the Scaler class.
 * 
 * @author Kayden Barlow
 */
class Monster extends Fighter implements ActionUser {
	
	private MonsterFlavor flavor;
	private int damage;
	private boolean stunned = false;
	private boolean special = false;
	private BasicAttack basicAttack;

	
	/**
	 * Constructor for instances of the Monster
	 * class. This includes a String for 
	 * the name and flavor text of the Monster, 
	 * as well it's level and initial health.
	 * 
	 * @param name String of the Monster's name.
	 * @param flavor String with the Monster's flavor
	 * text.
	 * @param level Integer value of the 
	 * Monster's relative power.
	 * @param maxHealth Integer value of the 
	 * Monster's maximum health points.
	 */
	Monster(String name, String flavor, int level, int maxHealth) {
		
		
		super(name, level, maxHealth);
		
		this.flavor = new MonsterFlavor();
		
		this.flavor.setStatusText(flavor);
		
		addStat(new MonsterStat(this));
		
		setBasic();
		
		setPronouns(PronounSet.neutralPronouns());
		
		prepare();
	}
	
	
	/**
	 * Constructor for instances of the Monster
	 * class. This includes a String for 
	 * the name and flavor text of the Monster, 
	 * as well it's level and initial health.
	 * 
	 * @param name String of the Monster's name.
	 * @param flavor MonsterFlavor containing
	 * the Monster's String information.
	 * @param level Integer value of the 
	 * Monster's relative power.
	 * @param maxHealth Integer value of the 
	 * Monster's maximum health points.
	 */
	Monster(String name, MonsterFlavor flavor, int level, int maxHealth) {
		
		super(name, level, maxHealth);
		
		this.flavor = flavor;

		addStat(new MonsterStat(this));
		
		setBasic();
		
		setPronouns(PronounSet.neutralPronouns());
		
		prepare();
	}
	
	
	/**
	 * Returns the MonsterFlavor object
	 * assigned to this Monster. 
	 * 
	 * @return MonsterFlavor assigned to
	 * this Monster.
	 */
	protected MonsterFlavor getFlavor() {
		
		return flavor;
	}
	
	
	/**
	 * Returns a String containing the
	 * Monster's name, level, and flavor
	 * text.
	 * 
	 * @return String containing end-user
	 * information about the Monster.
	 */
	public String statusMessage() {
		
		return (getName() + "'s Level: " + getLevel() + "\n" + flavor.getStatusText());
	}
	
	
	/**
	 * Outputs the Monster's flavor text.
	 * 
	 * @return String containing two lines of flavor text.
	 */
	public String flavorText() {
		
		return flavor.getStatusText();
	}
	
	
	/**
	 * Outputs the verb used in the Monster's
	 * basic attack.
	 * 
	 * @return String of the verb used to
	 * describe a basic attack.
	 */
	public String getAttackVerb() {
		
		return flavor.getAttackVerb();
	}
	
	
	
	/**
	 * Returns the word used for the Monster's
	 * "special", whose usage and tense may
	 * vary in subclass. 
	 * 
	 * @return String of the "special" word.
	 */
	protected String getSpecialWord() {
		
		return flavor.getSpecial();
	}
	
	
	/**
	 * Indicates if the Monster is set
	 * to try their special attack this 
	 * turn.
	 * 
	 * @return Boolean equal to the 
	 * Special parameter.
	 */
	protected boolean isOnSpecial() {
		
		return special;
	}
	
	/**
	 * Indicates if the Monster is
	 * unable to act.
	 * 
	 * @return Boolean equal to the 
	 * Stunned parameter.
	 */
	protected boolean isStunned() {
		
		return stunned;
	}
	
	
	/**
	 * Returns the current Damage value
	 * for this Monster.
	 * 
	 * @return Integer damage parameter.
	 */
	int getDamage() {
		
		return this.damage;
	}
	
	
	/**
	 * Constructs and sets the BasicAttack
	 * used for the eponymous parameter.  
	 */
	protected void setBasic() {
		
		basicAttack = new BasicAttack((Attacking)getStat("MonsterStat"));
		
		basicAttack.addDamageScaler(e -> {return getDamage();});
	}
	
	
	/**
	 * Sets the user's special parameter to
	 * the input boolean. Returns the 
	 * Boolean state that was set.
	 * 
	 * @param special Boolean used to set 
	 * the special parameter.
	 * @return True if special was set 
	 * True, False otherwise.
	 */
	protected boolean setSpecial(boolean special) {
		
		this.special = special;
		return this.special;
	}
	
	
	/**
	 * Determines if the Monster will
	 * attempt their special attack this
	 * turn. Returns the result of this
	 * operation.
	 * 
	 * @return True if special was set to
	 * True, False if not.
	 */
	protected boolean specialProcedure() {
		
		if ((new Random().nextInt(100)) < (8 + (2 * getLevel()))) {
			
			setSpecial(true);
		} else {
			
			setSpecial(false);
		}
		
		return special;
	}
	
	
	/**
	 * Sets the integer damage parameter to an int value 
	 * to a random number scaling based on the monster's level. 
	 * This number has a floor of one, and a ceiling 
	 * which scales faster than the player's normal damage
	 * number should. This is to create a more "random"
	 * damage amount for enemies. This method also randomly 
	 * determines if the monster currently has its special
	 * parameter set to True, with the percentage chance equaling
	 * eight plus twice its level.
	 * 
	 */
	public void prepare() {
		
		this.stunned = false;
		
		setDamage(Scaler.monsterDamage(getLevel()));
		
		specialProcedure();
	}
	
	
	
	/**
	 * Sets the Monster's damage parameter to the
	 * input value. Damage cannot be negative.
	 * If it is set to zero, Monster is stunned,
	 * and damage is recalculated as if normal 
	 * (in case a special overrides the stun).
	 * 
	 * @param damage Integer value of the
	 * Monster's new damage parameter.
	 * @return True if the Monster was 
	 * stunned by this reduction, False 
	 * otherwise.
	 */
	private boolean setDamage(int damage) {
		
		if (damage <= 0) {
			
			this.damage = Scaler.monsterDamage();
			
			this.stun();
			
			return true;
		} else {
		
			this.damage = damage;
		
			return false;
		}
	}
	
	
	/**
	 * Since the base Monster class
	 * is not terribly complex, disabling
	 * one simply causes it to be stunned. 
	 */
	/*public String disable(int potency) {
		
		stun();
		
		return "stun";
	}*/
	
	
	/**
	 * Reduces the Monster's upcoming
	 * damage. Returns True if this
	 * caused a stun by reducing that
	 * value to below zero.
	 */
	public boolean weaken(int potency) {
		
		return setDamage(getDamage() - potency);
	}
	
	
	/**
	 * Indicates if the Monster has
	 * been stunned by some process
	 * or another.
	 * 
	 * @return True if the Monster is
	 * stunned, False otherwise.
	 */
	public boolean isDisabled() {
		
		return stunned;
	}
	
	
	/**
	 * Causes the monster to be stunned, negating one
	 * turn: either the monster will be unable to take
	 * its next normal attack, or it will "downgrade" a 
	 * special hit to a normal attack.
	 */
	public void stun() {
		
		this.stunned = true;
	}
	
	/**
	 * Returns a message explaining
	 * that the Monster cannot
	 * harm its target this turn.
	 * 
	 * @return String describing the
	 * lack of a proper Action this 
	 * turn.
	 */
	protected String stunnedMessage(Entity target) {
		
		return formatMessage("[u] cannot harm " + target.getPerspectiveName() + "...\n\n");
	}
	
	/**
	 * Performs the Monster's BasicAttack
	 * and returns a String describing the
	 * results. 
	 * 
	 * @return String describing the effects
	 * of the BasicAttack.
	 */
	public String doBasic(Entity target) {
		
		return basicAttack.doAction(target);
	}
	
	
	/**
	 * Facilitates the effects of the monster's action
	 * and outputs a message indicating such. Note that 
	 * the stunned and special parameters are not reset 
	 * by this method, on the assumption that they will 
	 * be prepared before the next invocation of this method.
	 * 
	 * @param target Fighter targeted by the Monster.
	 * @return String of the message describing the 
	 * Monster's action.
	 */
	public String action(Entity target) {
		
		if (stunned && (!special)) {
		
			return stunnedMessage(target);	
		} else if (special && (!stunned)) {

			return formatMessage("Critical hit: [u] " + flavor.getSpecial() +
					" " + target.getPerspectiveName() + 
					".\n " + target.damageMessage(target.harm(2 * damage)));
		} else {
			//applies if neither stunned nor special, OR if both are true; special "overrides" stun.
			return doBasic(target);
		}
	}
	
	
	/*
	 * (Dummied interface designed to facilitate
	 * different enemy behaviors, didn't have time
	 * to implement
	public interface Behavior {
		
		
		boolean act(Monster actor);
	}
	
	
	
	protected static Behavior getBehavior(String name) {
		
		switch (name) {
			
		default: {
			
			return (m -> {
				
				if ((new Random().nextInt(100)) < (8 + (2 * m.getLevel()))) {
					
					return true;
				} else {
					
					return false;
				}
			});
		}
		} 
	}*/
	
	/*
	static String defaultString(String override, String def) {
		
		if (override == null) {
			
			return def;
		} else {
			
			return override;
		}
	}*/


	/**
	 * Action-adding method required by
	 * superclass. Currently unneeded
	 * and unused. 
	 */
	public boolean addAction(Action action) {
		
		return false;
	}


	/**
	 * Action-finding method required by
	 * superclass. Currently unneeded and
	 * unused.
	 */
	public Action getAction(String actionName) {

		return null;
	}


	/**
	 * Action-finding method required by
	 * superclass. Currently unneeded and
	 * unused.
	 */
	public Action getAction(Action action) {

		return null;
	}
}