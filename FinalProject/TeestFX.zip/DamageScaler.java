package finalProject;

/**
 * One-method interface intended for 
 * the scaling of individual Actions.
 * 
 * @author Kayden Barlow
 */
public interface DamageScaler {

	/**
	 * Returns a integer to be used for
	 * Action effects. The invoking Action
	 * is a parameter as to make use of 
	 * it or any related objects and their
	 * parameters when calculating the output. 
	 * 
	 * @param action Action invoking this method.
	 * @return Integer generated for scaling.
	 */
	int damage(Action action);
}
