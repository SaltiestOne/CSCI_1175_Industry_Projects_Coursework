package finalProject;

import java.util.ArrayList;
import java.util.Random;


/**
 * Abstract classs representing a some kind of combat 
 * participant. Makes use of the Gauge class to
 * facilitate the "health" parameter, as well as the 
 * Scaler class for some methods. Those classes will 
 * need to be present to instantiate a subclass of 
 * Fighter or use those methods, respectively.
 * 
 * @author Kayden Barlow
 */
abstract class Fighter implements Entity {
	
	private String name;
	private int level;
	private Gauge health;
	protected Stat[] stats = new Stat[3];
	protected BasicAttack basicAttack;
	private PronounSet pronouns;
	
	/**
	 * Constructor for instances of a Fighter
	 * subclass. On construction, the integer
	 * health parameter will be equal to
	 * the maximum health parameter.
	 * 
	 * @param name String name of the Fighter.
	 * @param level Integer value of the 
	 * Fighter's relative power.
	 * @param maxHealth Integer value of the 
	 * Fighter's maximum health points.
	 */
	Fighter(String name, int level, int health) {
		
		this.name = name;
		this.level = level;
		this.health = new Gauge(health);
	}
	
	
	/**
	 * No-arg constructor for instances of a
	 * Fighter subclass. Sets the name parameter
	 * to "Noone", level to 0, and 
	 * maximum/current health to 1.
	 * 
	 * 
	 */
	Fighter() {
		
		this("Noone", 0, 1);
	}
	
	
	
	public String getName() {
		
		return name;
	}


	/**
	 * Returns a name appropriate for referring
	 * to the Fighter in a proper sentence. By
	 * defualt, this simply adding "the" to the 
	 * name parameter, but this can be overriden
	 * in subclasses.
	 * 
	 * @return String of the Fighter's name
	 * preceeded by "the".
	 */
	public String getPerspectiveName() {
		
		return ("the " + getName());
	}
	
	
	
	public int getLevel() {
		
		return level;
	}
	
	
	/**
	 * Sets the Fighter's level to the 
	 * input integer. Level cannot
	 * be negative.
	 * 
	 * @param level Integer value of 
	 * new level.
	 */
	protected void setLevel(int level) {
		
		if (level <= 0) {
			
			level = 0;
		} else {
			
			this.level = level;
		}
	}
	
	
	
	public int getMaxHealth() {
		
		return health.getMax();
	}
	
	
	/**
	 * Adjusts the Fighter's maximum
	 * health parameter to the input amount.
	 * Maximum health cannot be negative.
	 * If current health exceeds the new value,
	 * or if the boolean input is set to "True"
	 * (the latter is intended as "full heal"
	 * as part of a level-up), then health
	 * is set equal to the value of maximum
	 * health.
	 */
	public void setMaxHealth(int maxHealth, boolean heal) {
		
		health.setMax(maxHealth, heal);
	}
	
	
	public int getHealth() {
		
		return health.getCurrent();
	}

	
	/**
	 * Adjusts the Fighter's health parameter
	 * to the input integer. Health cannot
	 * be negative or exceed the Fighter's 
	 * maximum health parameter.
	 * 
	 * @param health Integer value of the
	 * Fighter's new health parameter.
	 */
	public void setHealth(int health) {
		
		this.health.setCurrent(health);
	}
	
	
	
	/**
	 * Adds the input Stat object to
	 * this Fighter's "stats" ArrayList.
	 * By default, all Stat subclasses 
	 * invoke this on thier constructing
	 * Fighter during their instantiation. 
	 * 
	 * @return Boolean indicating if there
	 * was room to add the input Stat.
	 */
	public boolean addStat(Stat stat) {
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s] == null) {
				
				stats[s] = stat;
				
				if (this instanceof ActionUser) {
					
					stat.addActions();
				} else {}
				
				if (stat instanceof Attacking) {
					
					setBasic();
				} else {}
				
				return true;
			} else {}
		}

		return false;
	}
	
	
	/**
	 * Returns the full "stats" array
	 * containing all non-null Stat objects 
	 * associated with this Fighter. 
	 * 
	 * @return Stat array listing
	 * all Stat objects associated with
	 * invoking Fighter.
	 */
	public Stat[] getStats() {
		
		if (!maxNumOfStats()) {
			
			int count = 0;
			
			Stat[] getter = new Stat[stats.length];
			
			for (int s = 0; s < stats.length; s++) {
				
				if (stats[s] != null) {
					
					getter[count++] = stats[s];
				} else {}
			}
			
			Stat[]	result = new Stat[count];
			
			System.arraycopy(getter, 0, result, 0, count);
			
			return result;
		} else {
			
			return this.stats;
		}
	}
	
	
	/**
	 * Returns one of this Fighter's 
	 * associated Stat objects. Input 
	 * String is the name of the 
	 * desired Stat object, which in
	 * most cases will be the name 
	 * of the Class of the Stat.
	 * Throws an exception if no
	 * Stat with the input name is
	 * found. 
	 * 
	 * @param statName String of the
	 * name of the desired Stat.
	 * @return Stat object matching 
	 * the input name String.
	 */
	public Stat getStat(String statName) {
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s] != null) {
				
				if (stats[s].getName().equals(statName)) {
				
					return stats[s];
				} else {}
			} else {}
		}
		
		throw new NullPointerException("\"" + statName + "\" Stat not found!");
	}
	

	
	/**
	 * Indicates if this Fighter has
	 * been the max number of Stat objects. 
	 * 
	 * @return True if all Stat slots are
	 * filled, False otherwise.
	 */
	public boolean maxNumOfStats() {
		
		for (int s = 0; s < stats.length; s++) {
			
			if (stats[s] == null) {
				
				return false;
			} else {}
		}
		
		return true;
	}
	
	
	/**
	 * Indicates if all of the Fighter's
	 * associated Stat objects are at 
	 * their maximum level. 
	 * 
	 * @return True if all Stat objects are
	 * at maximum level, False otherwise.
	 */
	public boolean statsAtMax() {
		
		try {
			for (int s = 0; s < stats.length; s++) {
				
				if (!stats[s].isAtMax()) {
					
					return false;
				} else {}
			}
		} catch (NullPointerException ex) {
			
			return false;
		}
		
		return true;
	}
	
	/**
	 * Assigns a PronounSet object to
	 * the pronouns parameter for use
	 * in formatting sentences and such. 
	 * 
	 * @param pronouns PronounSet to be
	 * used by this Fighter.
	 */
	public void setPronouns(PronounSet pronouns) {
		
		this.pronouns = pronouns;
	}
	
	public PronounSet getPronouns() {
		
		return pronouns;
	}
	
	/**
	 * Formats the input message to
	 * use this Fighter's pronouns and
	 * perspective name. 
	 */
	public String formatMessage(String message) {
		
		message = PronounSet.formatPronouns(message, getPronouns());
		message = message.replace("[u]", getPerspectiveName());
		
		return message;
	}
	
	
	/**
	 * Returns a String displaying 
	 * max and current health.
	 * 
	 * @return A String with the current and max health,
	 * seperated by a slash.
	 */
	public String healthGauge() {
		
		return health.getGauge();
	}
	
	
	public String damageMessage(int damage) {
		
		return Formatter.capitalize(formatMessage(" [u] take[s] " +
				damage + " damage.\n"));
	}
	
	
	
	/**
	 * Indicates if the health parameter is 
	 * less than its maximum value. 
	 * 
	 */
	public boolean isDamaged() {
		
		return (!(health.isFull()));
	}
	
	
	/**
	 * Indicates if the health parameter
	 * is equal to zero.
	 * 
	 * @return True if the health parameter
	 * is equal to zero, False otherwise.
	 */
	public boolean isDead() {
		
		return health.isEmpty();
	}
	
	
	
	
	
	/**
	 * Reduces this Fighter's health parameter
	 * by the input amount. Health cannot be 
	 * negative. Output is identical to the input.
	 * 
	 * @param damage Integer reduction to Fighter's
	 * health parameter.
	 * @return Integer identical to input.
	 */
	public int harm(int damage) {
		
		health.adjust(-damage);
		
		return damage;
	}
	
	
	/**
	 * Increases this Fighter's health parameter
	 * by the input amount. Health cannot go above
	 * the Fighter's maximum health parameter. 
	 * Output is identical to the input.
	 * 
	 * @param damage Integer increase to Fighter's
	 * health parameter.
	 * @return Integer identical to input.
	 */
	public int heal(int cure) {
		
		health.adjust(cure);
		
		return cure;
	}
	
	/**
	 * Sets up a basic attack 
	 * (which may or may not be
	 * facilitated by the eponymous
	 * Action subclass) for use by 
	 * the doBasic() method.
	 */
	abstract protected void setBasic();
	
	/**
	 * Facilitates the Fighter performing thier
	 * most basic, repeatable form of 
	 * attack. Outputs a String describing
	 * the effects of such.
	 * 
	 * @param target Entity targetted by the
	 * basic attack.
	 * @return String describing the effects
	 * of the attack.
	 */
	abstract public String doBasic(Entity target);
	
	//abstract public String disable(int potency);
	
	abstract public boolean weaken(int potency);
	
	abstract public String statusMessage();
}