package finalProject;


/**
 * Interface marking that this Stat
 * creates a BasicAttack.
 * 
 * @author Kayden Barlow
 */
public interface Attacking {

	/**
	 * Integer value determining
	 * which Attacking stat has priority
	 * to create and assign its BasicAttack
	 * in the event that an Entity has
	 * more than one Attacking Stat assigned.
	 * Will typically be equal to its
	 * Scaling value (so that, in theory,
	 * the most potent BasicAttack will be
	 * created) unless otherwise noted.
	 * 
	 * @return Integer value of the relative
	 * priority of this Attacking Stat over
	 * any others.
	 */
	public int attackPriority();
	
	
	/**
	 * String used to construct the 
	 * message returned when using the
	 * BasicAttack generated from this
	 * Attacking Stat.
	 * 
	 * @return String displayed when
	 * attacking with this Attacking Stat.
	 */
	public String attackMessage();
	
	
	/**
	 * Constructs the BasicAttack
	 * based on this Attacking Stat. 
	 * 
	 * @return BasicAttack derived from
	 * this Attacking Stat.
	 */
	public BasicAttack getBasicAttack();	
}