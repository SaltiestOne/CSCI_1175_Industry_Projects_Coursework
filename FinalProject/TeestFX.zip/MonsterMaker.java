package finalProject;
import java.util.Random;

/**
 * Abstract class containing static methods
 * used to build a Monster object from a list
 * of pre-written Strings, scaling its health
 * and level from the Scaler class.
 * 
 * @author Kayden Barlow
 */
abstract class MonsterMaker {

	private static String[][] monsters;
	public static boolean set = false;

	/**
	 * Outputs a Monster object randomly
	 * determined from a static list of
	 * String array constructors. The potential
	 * output varies based on the round
	 * parameter of the Scaler class, 
	 * with its level and health scaling
	 * from the same parameter. 
	 * 
	 * @return Monster object created at
	 * random.
	 */
	public static Monster make() {
		
		set();
		
		return make(Math.min(monsters.length,
			(new Random().nextInt((4 + (int)(1.2 * Scaler.getRound()))) + (Scaler.getRound() - 1))));
	}
	
	
	/**
	 * Outputs a Monster object randomly
	 * determined from a static list of
	 * String array constructors, as determined
	 * by the input id number.
	 * 
	 * @return Monster object specified by
	 * input id.
	 */
	public static Monster make(int id) {
		
		set();
		
		int round = Scaler.getRound();

		String[] seed = monsters[id];

		PronounSet pronouns; 
		//= PronounSet.neutralPronouns();
		
		switch (seed[1]) {
		
		case ("m"): {
			
			pronouns = PronounSet.malePronouns();
			break;
		}
		
		case ("f"): {
			
			pronouns = PronounSet.femalePronouns();
			break;
		}
		
		case ("e"): {
			
			pronouns = PronounSet.randomGenderPronouns();
			break;
		}
		
		case ("p"): {
			
			pronouns = PronounSet.pluralPronouns();
			break;
		}
		
		default: {
			
			pronouns = PronounSet.neutralPronouns();
		}
		}
		
		MonsterFlavor flavor = new MonsterFlavor();
		
		flavor.setAttackVerb(seed[2]);
		flavor.setStatusText((seed[6] + "\n" + seed[7] + "\n"));
		flavor.setSpecial(seed[3]);
		
		try {
			
			switch (seed[4]) {
			
			case ("Critter"): {
				
				Monster output = new Monster(seed[0], flavor, round, Scaler.enemyHealth(round));
				
				output.setPronouns(pronouns);
				
				return output;
			}
			
			case ("Skilled"): {
				
				SkilledMonster output = new SkilledMonster(seed[0], flavor, round, 
						Scaler.enemyHealth(round));
	
				output.setSkill(new Skill(seed[5], true, 1, output.getStat("MonsterStat"), true));
				output.setPronouns(pronouns);
				
				return output;
			}
			
			case ("Caster"): {
				
				Spellcaster output = new Spellcaster(seed[0], flavor, round,
						Scaler.enemyHealth(round));
				
				output.setSpell(new Spell(seed[5], true, 2, output.getStat("MonsterStat"), true));
				output.setPronouns(pronouns);
				
				return output;		
			}
				
			default: {
				
				throw new IllegalArgumentException("too lazy");
			}
				
			}
		} catch (IllegalArgumentException ex) {
			
			System.out.print(ex.getLocalizedMessage());

			Monster output = new Monster(seed[0], flavor, round, Scaler.enemyHealth(round));
			
			output.setPronouns(pronouns);
			
			return output; 
		}
		
	}
	
	
	/**
	 * Assigns the static list of potential
	 * Monster constructor String arrays with
	 * a pre-written list. To prevent redundant
	 * tasks, checks a static boolean before
	 * doing this, which is set True the first 
	 * time this method is invoked. 
	 */
	public static void set() {
		
		if (!set) {
			
			monsters = new String [][] { 
				{"Rat", "i", "bites", "chomps", "Critter", "",
					"Not even a big one. It's, like, a foot from nose to tail.",
					"It's only trouble because it's so hard to hit."}, 
				{"Tree Snake", "i", "bites", "lunges at", "Critter", "",
					"Mostly eats small animals. Lays on treetops for warmth.",
					"Attacks in self-defense if knocked off the branches."}, 
				{"Half-Skeleton", "i", "tackles", "strangles", "Critter", "",
					"Shambles around missing an arm, its feet, and some ribs.",
					"Crawls on 'all threes' and throws itself at threats."},
				{"Lone Wolf", "i", "bites", "pounces on", "Critter", "",
					"Usually, the lone wolves are that way for a reason.",
					"This one MIGHT just be misunderstood. But I doubt it."},
				{"Baby Chimera", "i", "rams into", "pins", "Critter", "",
					"Chimeras born in the wild start off relatively weak.",
					"Coordinating all their different parts takes practice."},
				{"Wolfrat", "i", "bites", "gouges", "Critter", "",
					"Despite the name, they're a carnivorous cousin of rabbits.",
					"But a layman could assume them to be wolf-rat hybrids."},
				{"Poacher", "e", "shoots at", "man-catcher", "Skilled", "Lunge",
					"\"Poacher\" is used here euphamistically.",
					"Illegal hunting is a lesser crime than others."},
				{"Dozentalon", "i", "scrapes", "pounces on", "Critter", "",
					"Bird of prey with large wings and two pairs of clawed limbs.",
					"A famous poem asks, 'Be a dragon, or a gryphon, that bird?'"},
				{"Ice-Mote", "i", "chills", "ice", "Caster", "Drain",
					"Is it an Air or Water Elemental? Both? Neither?",
					"Many arcanologists have lost friendships over this debate."},
				{"Amalgnomes", "p", "punches", "reinforced shell", "Skilled", "Counter",
					"A number of gnomes operating a humanoid construct.",
					"Which of its body parts are \"piloted\" may vary."},
				{"Bandette", "f", "chops", "axe", "Skilled", "Eviscerate",
					"Has many cheap romance novels hidden under her loot stash.",
					"A hostage nobleman falls for his captor in most of them."},
				{"Green Slime", "i", "splashes", "corrodes", "Critter", "",
					"Orcs love these, and eat them raw like in the stories.",
					"Half-orcs hate these, because of stereotypes."},
				{"Catalin Daerg", "i", "stabs", "arms", "Skilled", "Lunge",
					"This fae warrior appears as a green knight with spears for arms.",
					"Having no mouth, it's easily the most trustworthy type of fairy."},
				{"Swordist", "e", "counters", "shield", "Skilled", "Shield Bash",
					"A catch-all term for proficient users of a sword and shield.",
					"A mercenary, bandit, guard... whichever happens to be fighting you."},
				{"Paladin", "e", "shield-bashes", "shield", "Caster", "Astra",
					"One who uses a shield and magic to defend... something.",
					"Sanctioned holy warriors are called this only as an insult."},
				{"Battle-Mage", "e", "strikes", "spear", "Caster", "Mana Burst(Sp)",
					"Student of both martial and arcane arts, out to prove something.",
					"Channels various spells through an overdesigned two-handed weapon."},
				{"Refuse Golem", "i", "tosses", "lays waste to", "Critter", "",
					"One can really get their mana's worth out of one of these.",
					"They're not only cheaper than other golems, but scarier too."},
				{"Earth Angel", "i", "dusts", "buries", "Critter", "",
					"A lizard that hosts special Earth Elementals on its skin.",
					"These envelop the creature in a mass of soil, sand, or clay."},
				{"Haunted Blade", "p", "slashes at", "own body", "Caster", "Mana Burst(Sp)", 
					"A worn, discarded sword possessed by a resentful spirit.",
					"Perhaps they, too, felt like an unwanted weapon."},
				{"Edge-Lord", "m", "cuts", "razor", "Skilled", "Eviscerate",
					"Some are mockingly called \"Lords\" of the \"Edge\" of society.",
					"Most are people who traded their morals for power of some kind."},
				{"Blue Wyvern", "i", "snatches", "chomps", "Critter", "",
					"This subspecies's breath \"weapon\" isn't harmful; it regulates heat.",
					"This lets it survive in more enviornments than any of its cousins."},
				/*{"[multiple swordists]", "engage", "surround",
					"A group of swordists trained to coordinate in combat.",
					"Members typically use different, complimenting styles."},*/
				{"Gungnir", "e", "Mana-Bursts", "sharpstaff", "Caster", "Astra", 
					"A title given to those who harmonize their bodies with the arcane.",
					"Many adopt the use of a hybrid staff-spear in combat."},
				{"False Phoenix", "p", "singes", "ashes", "Caster", "Bolt",
					"A bird that creates fire to assist with flight, hunting, and defense.",
					"Known by other names in places without a concept of a \"phoenix.\""},
				{"Wheelchair Drake", "m", "rolls into", "yuhs", "Critter", "",
					"Congrats. You're clearly strong enough and lucky enough.",
					"You've earned the right to fight the token joke enemy."},
				{"Hero's Shadow", "p", "mimics", "nullifies", "Critter", "",
					"None can deafeat their own shadow, only hold it back.",
					"And sometimes, it becomes more popular than its original."}};
					
				set = true;
				
		} else {}
	}
}
