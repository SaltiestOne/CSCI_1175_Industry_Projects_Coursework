package finalProject;

/**
 * ActionUser subinterface denoting Entities
 * that are able to use Mana-consuming Actions
 * (chiefly Spells).
 * 
 * @author Kayden Barlow
 */
public interface Caster extends ActionUser {

	/**
	 * Adjusts the maximum Mana
	 * value to the input integer. 
	 * Cannot be negative.
	 * 
	 * @param maxMana Integer of the new
	 * maximum Mana value.
	 * @param maximize Boolean determining
	 * if the available Mana value is set to
	 * the new Maximum.
	 */
	public void setMaxMana(int maxMana, boolean maximize);
	
	
	/**
	 * Returns the value of the Caster's
	 * maximum Mana paramater.
	 * 
	 * @return Integer maximum Mana.
	 */
	public int getMaxMana();
	
	/**
	 * Sets the Caster's currently available Mana
	 * to the input amount. This cannot be
	 * negative, or exceed the maximum Mana 
	 * value.
	 * 
	 * @param mana Integer new Mana value.
	 */
	public void setMana(int mana);

	/**
	 * Returns the integer value of the
	 * Caster's available Mana.
	 * 
	 * @return Integer of available Mana.
	 */
	public int getMana();

	/**
	 * Shifts the Mana parameter 
	 * an amount equal to the
	 * input Integer. Input can be
	 * made negative to decrease Mana.
	 * Mana should not be negative nor 
	 * should it exceed the maximumMana
	 * parameter. 
	 * 
	 * @param mana Integer amount to
	 * add to (or subtract from) Mana.
	 */
	public void adjustMana(int amount);
}
